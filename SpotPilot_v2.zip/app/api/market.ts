const HOSTS = ["https://data-api.binance.vision", "https://api.binance.com"];
const STABLE_BASES = new Set(["USDC", "FDUSD", "TUSD", "USDP", "DAI", "BUSD", "USD1", "EUR", "EURI", "AEUR", "RLUSD", "XUSD", "RWUSD", "USDE", "USDS", "PYUSD", "USDG", "USDD", "USDX", "USDY", "BFUSD"]);
const LEVERAGED = /(?:UP|DOWN|BULL|BEAR)USDT$/;

export type Ticker = {
  symbol: string;
  price: number;
  changePercent: number;
  high: number;
  low: number;
  quoteVolume: number;
};

export type Candle = {
  openTime: number;
  closeTime: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  quoteVolume: number;
};

type TickerCache = { data: Ticker[]; asOf: number } | { data: null; asOf: 0 };
const tickerCache: TickerCache = { data: null, asOf: 0 };
const candleCache = new Map<string, { data: Candle[]; asOf: number }>();

async function fetchJson<T>(path: string): Promise<T> {
  let lastError: unknown;
  for (const host of HOSTS) {
    try {
      const response = await fetch(`${host}${path}`, {
        signal: AbortSignal.timeout(9000),
        headers: { Accept: "application/json" },
      });
      if (!response.ok) throw new Error(`Market feed returned ${response.status}`);
      return (await response.json()) as T;
    } catch (error) {
      lastError = error;
    }
  }
  throw lastError instanceof Error ? lastError : new Error("Market feed unavailable");
}

function liquidSpotTicker(item: {
  symbol: string;
  lastPrice: string;
  priceChangePercent: string;
  highPrice: string;
  lowPrice: string;
  quoteVolume: string;
}): Ticker | null {
  const base = item.symbol.slice(0, -4);
  if (!item.symbol.endsWith("USDT") || STABLE_BASES.has(base) || LEVERAGED.test(item.symbol)) return null;
  const ticker = {
    symbol: item.symbol,
    price: Number(item.lastPrice),
    changePercent: Number(item.priceChangePercent),
    high: Number(item.highPrice),
    low: Number(item.lowPrice),
    quoteVolume: Number(item.quoteVolume),
  };
  if (!Object.values(ticker).every((value) => typeof value === "string" || Number.isFinite(value))) return null;
  return ticker.price > 0 ? ticker : null;
}

export async function getTickers(): Promise<{ data: Ticker[]; asOf: number; stale: boolean }> {
  if (tickerCache.data && Date.now() - tickerCache.asOf < 20_000) {
    return { data: tickerCache.data, asOf: tickerCache.asOf, stale: false };
  }
  try {
    const raw = await fetchJson<Array<{
      symbol: string;
      lastPrice: string;
      priceChangePercent: string;
      highPrice: string;
      lowPrice: string;
      quoteVolume: string;
    }>>("/api/v3/ticker/24hr");
    const data = raw
      .map(liquidSpotTicker)
      .filter((item): item is Ticker => item !== null)
      .sort((a, b) => b.quoteVolume - a.quoteVolume);
    tickerCache.data = data;
    tickerCache.asOf = Date.now();
    return { data, asOf: tickerCache.asOf, stale: false };
  } catch (error) {
    if (tickerCache.data) return { data: tickerCache.data, asOf: tickerCache.asOf, stale: true };
    throw error;
  }
}

type KlineRow = [
  number, string, string, string, string, string, number, string, ...unknown[]
];

export async function getCandles(symbol: string, interval: "1m" | "1h" | "4h" | "1d" = "4h", limit = 50) {
  if (!/^[A-Z0-9]{5,20}$/.test(symbol)) throw new Error("Invalid market symbol");
  if (!Number.isInteger(limit) || limit < 1 || limit > 5000) throw new Error("Invalid candle limit");
  const key = `${symbol}:${interval}:${limit}`;
  const cached = candleCache.get(key);
  if (interval !== "1m" && cached && Date.now() - cached.asOf < 60_000) return cached.data;

  const batches: KlineRow[][] = [];
  let endTime: number | null = null;
  let remaining = limit;
  while (remaining > 0) {
    const batchLimit = Math.min(1000, remaining);
    const end: string = endTime === null ? "" : `&endTime=${endTime}`;
    const raw: KlineRow[] = await fetchJson<KlineRow[]>(
      `/api/v3/klines?symbol=${symbol}&interval=${interval}&limit=${batchLimit}${end}`,
    );
    batches.unshift(raw);
    remaining -= raw.length;
    if (raw.length < batchLimit || raw.length === 0) break;
    endTime = raw[0][0] - 1;
  }

  const data = batches.flat().map((row) => ({
    openTime: row[0],
    open: Number(row[1]),
    high: Number(row[2]),
    low: Number(row[3]),
    close: Number(row[4]),
    volume: Number(row[5]),
    closeTime: row[6],
    quoteVolume: Number(row[7]),
  })).slice(-limit);
  candleCache.set(key, { data, asOf: Date.now() });
  return data;
}

export async function getLastPrice(symbol: string) {
  const tickers = await getTickers();
  const ticker = tickers.data.find((item) => item.symbol === symbol);
  if (!ticker) throw new Error(`No ticker found for ${symbol}`);
  return ticker.price;
}
