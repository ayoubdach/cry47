import { describe, expect, it } from "vitest";
import { analyseTrendPullback, isDailyUptrend } from "./trend-strategy";
import {
  candle,
  dailyCandlesEnding,
  DAY,
  FOUR_HOURS,
  marketCandles,
  testTicker,
} from "./test-fixtures";

function pullbackFixture() {
  const candles = marketCandles();
  candles[59] = candle(59, 104.6, 105.6, 104.2, 105.2);
  const now = 60 * FOUR_HOURS;
  return { candles, now, daily: dailyCandlesEnding(now) };
}

describe("Daily trend and 4H pullback strategy", () => {
  it("requires close above EMA50, EMA20 above EMA50, and a rising EMA50", () => {
    const end = 80 * DAY;
    expect(isDailyUptrend(dailyCandlesEnding(end), end)).toBe(true);
    expect(isDailyUptrend(dailyCandlesEnding(end, 70, false), end)).toBe(false);
    expect(isDailyUptrend(dailyCandlesEnding(end, 40), end)).toBe(false);
  });

  it("detects a bullish 4H rejection from the EMA pullback zone", () => {
    const { candles, now, daily } = pullbackFixture();
    const candidate = analyseTrendPullback(
      { ...testTicker(), price: candles.at(-1)!.close },
      candles,
      daily,
      now,
    );
    expect(candidate).not.toBeNull();
    expect(candidate?.strategy).toBe("trend_pullback");
    expect(candidate?.status).toBe("armed");
    expect(candidate?.stopLoss).toBeLessThan(candidate!.entryLow);
    expect(candidate?.target3).toBeGreaterThan(candidate!.target2);
  });

  it("rejects bearish confirmation and a bearish Daily trend", () => {
    const { candles, now, daily } = pullbackFixture();
    const bearish = [...candles];
    bearish[59] = candle(59, 105.5, 105.6, 104.2, 104.8);
    expect(analyseTrendPullback(testTicker(), bearish, daily, now)).toBeNull();
    expect(analyseTrendPullback(testTicker(), candles, dailyCandlesEnding(now, 70, false), now)).toBeNull();
  });

  it("does not use Daily candles from the future", () => {
    const { candles, now, daily } = pullbackFixture();
    const futureDaily = [...daily, {
      ...daily.at(-1)!,
      openTime: now + DAY,
      closeTime: now + 2 * DAY - 1,
      close: 1,
    }];
    const baseline = analyseTrendPullback(testTicker(), candles, daily, now);
    const withFuture = analyseTrendPullback(testTicker(), candles, futureDaily, now);
    expect(withFuture?.entryLow).toBe(baseline?.entryLow);
    expect(withFuture?.entryHigh).toBe(baseline?.entryHigh);
  });
});
