import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getCandles, getTickers } from "./market";
import { runRadar } from "./radar";
import { runBacktest } from "./backtest";
import { getLatestBacktest } from "./queries/backtests";
import { runScan } from "./scanner";
import { sendTelegram, telegramConfig } from "./telegram";
import {
  addAlert,
  cancelSetup,
  createSetup,
  ensureStarterSetups,
  listAlerts,
  listSetups,
} from "./queries/setups";

const symbolInput = z.string().regex(/^[A-Z0-9]{5,20}$/, "Invalid market symbol");

const setupInput = z.object({
  symbol: symbolInput,
  breakout: z.coerce.number().positive(),
  entryLow: z.coerce.number().positive(),
  entryHigh: z.coerce.number().positive(),
  stopLoss: z.coerce.number().positive(),
  target1: z.coerce.number().positive(),
  target2: z.coerce.number().positive(),
  target3: z.coerce.number().positive(),
  cancelBelow: z.coerce.number().positive(),
  riskPercent: z.coerce.number().min(0.1).max(2),
  entryMode: z.enum(["touch", "confirmed"]).default("touch"),
}).refine((s) => s.stopLoss < s.entryLow && s.entryLow <= s.entryHigh && s.entryHigh < s.breakout, {
  message: "Required order: stop < entry low ≤ entry high < breakout",
}).refine((s) => s.cancelBelow <= s.entryLow && s.cancelBelow >= s.stopLoss, {
  message: "Cancellation must sit between the stop and entry low",
}).refine((s) => s.breakout < s.target1 && s.target1 < s.target2 && s.target2 < s.target3, {
  message: "Targets must increase above the breakout",
});

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),

  market: createRouter({
    tickers: publicQuery.query(() => getTickers()),
    candles: publicQuery
      .input(z.object({
        symbol: symbolInput,
        interval: z.enum(["1h", "4h"]).default("4h"),
        limit: z.number().int().min(20).max(100).default(50),
      }))
      .query(({ input }) => getCandles(input.symbol, input.interval, input.limit)),
  }),

  setups: createRouter({
    list: publicQuery.query(async () => {
      await ensureStarterSetups();
      return listSetups();
    }),
    create: publicQuery.input(setupInput).mutation(async ({ input }) => {
      const created = await createSetup({
        ...input,
        breakout: String(input.breakout),
        entryLow: String(input.entryLow),
        entryHigh: String(input.entryHigh),
        stopLoss: String(input.stopLoss),
        target1: String(input.target1),
        target2: String(input.target2),
        target3: String(input.target3),
        cancelBelow: String(input.cancelBelow),
        riskPercent: String(input.riskPercent),
        source: "manual",
        strategy: "breakout",
        entryMode: input.entryMode,
        status: "waiting",
      });
      if (created) {
        const title = `${created.symbol.replace("USDT", "/USDT")} paper setup created`;
        const message = `Watching for a 4H close above ${Number(created.breakout).toLocaleString("en-US")}. No entry before confirmation.`;
        await addAlert({ setupId: created.id, kind: "created", title, message });
      }
      return created;
    }),
    cancel: publicQuery.input(z.object({ id: z.number().int().positive() })).mutation(async ({ input }) => {
      const setup = await cancelSetup(input.id);
      if (setup) {
        const title = `${setup.symbol.replace("USDT", "/USDT")} setup closed manually`;
        const message = "Setup cancelled by the operator. No further entry is valid.";
        await addAlert({ setupId: setup.id, kind: "cancelled", title, message });
      }
      return setup;
    }),
  }),

  alerts: createRouter({
    list: publicQuery.query(() => listAlerts(40)),
  }),

  scan: createRouter({
    run: publicQuery.mutation(() => runScan()),
  }),

  radar: createRouter({
    run: publicQuery.mutation(() => runRadar()),
  }),

  backtests: createRouter({
    latest: publicQuery.query(() => getLatestBacktest()),
    run: publicQuery
      .input(z.object({
        markets: z.number().int().min(8).max(40),
        candles: z.number().int().min(300).max(3000),
      }))
      .mutation(({ input }) => runBacktest(input)),
  }),

  telegram: createRouter({
    status: publicQuery.query(() => telegramConfig()),
    test: publicQuery.mutation(async () => {
      if (!telegramConfig().configured) return { delivered: false as const };
      return sendTelegram("✅ <b>SpotPilot connected</b>\nYou will get alerts for entries, targets and stops.\n📝 <i>Paper trade · no real orders</i>");
    }),
  }),
});

export type AppRouter = typeof appRouter;
