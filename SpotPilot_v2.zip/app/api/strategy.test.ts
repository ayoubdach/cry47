import { describe, expect, it } from "vitest";
import { analyseMarket, historicalTicker, isConfirmedRetest, scoreAccepted, zoneTouched } from "./strategy";
import { candle, FOUR_HOURS, marketCandles, testTicker } from "./test-fixtures";

describe("breakout-retest strategy", () => {
  it("distinguishes a waiting structure from a fresh closed breakout", () => {
    const waiting = analyseMarket(testTicker(), marketCandles(), 60 * FOUR_HOURS);
    const breakout = analyseMarket(testTicker(), marketCandles(true), 61 * FOUR_HOURS);

    expect(waiting?.status).toBe("waiting");
    expect(breakout?.status).toBe("armed");
    expect(breakout?.stopLoss).toBeLessThan(breakout!.entryLow);
    expect(breakout!.entryHigh).toBeLessThan(breakout!.breakout);
    expect(breakout!.breakout).toBeLessThan(breakout!.target1);
  });

  it("does not use future candles or the breakout candle to define resistance", () => {
    const candles = marketCandles();
    const now = 60 * FOUR_HOURS;
    const baseline = analyseMarket(testTicker(), candles, now);
    const future = candle(60, 106, 10_000, 1, 9_000);
    const withFuture = analyseMarket(testTicker(), [...candles, future], now);

    expect(withFuture?.breakout).toBe(baseline?.breakout);
    expect(withFuture?.score).toBe(baseline?.score);
  });

  it("requires a real zone touch and bullish close above the zone for confirmation", () => {
    const levels = { entryLow: 99, entryHigh: 100 };
    const confirmed = candle(70, 100.2, 101, 99.5, 100.6);
    const bearish = candle(71, 100.2, 101, 99.5, 99.8);
    const noTouch = candle(72, 100.2, 101, 100.1, 100.6);

    expect(zoneTouched(confirmed, levels)).toBe(true);
    expect(isConfirmedRetest(confirmed, levels)).toBe(true);
    expect(isConfirmedRetest(bearish, levels)).toBe(false);
    expect(isConfirmedRetest(noTouch, levels)).toBe(false);
  });

  it("rejects thin markets while allowing high-quality secondary liquidity", () => {
    const candles = marketCandles();
    const rejected = analyseMarket({ ...testTicker(), quoteVolume: 4_900_000 }, candles, 60 * FOUR_HOURS);
    const accepted = analyseMarket({ ...testTicker(), quoteVolume: 6_000_000 }, candles, 60 * FOUR_HOURS);
    expect(rejected).toBeNull();
    expect(accepted).not.toBeNull();
  });

  it("applies the score-85 threshold only to the elite breakout variant", () => {
    expect(scoreAccepted(84, "breakout_daily_elite")).toBe(false);
    expect(scoreAccepted(85, "breakout_daily_elite")).toBe(true);
    expect(scoreAccepted(65, "breakout_daily")).toBe(true);
    expect(scoreAccepted(65, "breakout")).toBe(true);
  });

  it("uses rolling historical quote volume rather than current 24H liquidity", () => {
    const candles = marketCandles(true);
    const historical = historicalTicker(candles);
    expect(historical.quoteVolume).toBeCloseTo(
      candles.slice(-6).reduce((sum, item) => sum + item.quoteVolume, 0),
    );
  });
});
