import { afterEach, describe, expect, it, vi } from "vitest";
import { getCandles } from "./market";
import { FOUR_HOURS } from "./test-fixtures";

function kline(index: number) {
  const price = String(100 + index / 100);
  return [index * FOUR_HOURS, price, price, price, price, "1000", (index + 1) * FOUR_HOURS - 1, "100000", ...[]];
}

afterEach(() => vi.unstubAllGlobals());

describe("long-range market history", () => {
  it("paginates beyond Binance's 1,000-candle response limit in chronological order", async () => {
    const rows = Array.from({ length: 1500 }, (_, index) => kline(index));
    const requested: string[] = [];
    vi.stubGlobal("fetch", vi.fn(async (input: string | URL | Request) => {
      const url = String(input);
      requested.push(url);
      const endTime = new URL(url).searchParams.get("endTime");
      const batch = endTime === null ? rows.slice(500) : rows.slice(0, 500);
      return new Response(JSON.stringify(batch), { status: 200 });
    }));

    const candles = await getCandles("PAGINATEUSDT", "4h", 1500);

    expect(requested).toHaveLength(2);
    expect(requested[0]).toContain("limit=1000");
    expect(requested[1]).toContain("limit=500");
    expect(requested[1]).toContain(`endTime=${rows[500][0] as number - 1}`);
    expect(candles).toHaveLength(1500);
    expect(candles[0].openTime).toBe(rows[0][0]);
    expect(candles.at(-1)!.openTime).toBe(rows.at(-1)![0]);
  });
});
