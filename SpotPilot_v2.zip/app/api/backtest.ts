import { randomUUID } from "node:crypto";
import { getCandles, getTickers, type Candle } from "./market";
import { simulateMarket, summariseBacktest, type BacktestTrade } from "./backtest-engine";
import type { EntryMode, StrategyVariant } from "./strategy";
import { createBacktestRun, getBacktestGroup, getLatestBacktest } from "./queries/backtests";

const FEE_BPS = 10;
const SLIPPAGE_BPS = 5;
const VARIANTS: Array<{ strategy: StrategyVariant; entryMode: EntryMode }> = [
  { strategy: "breakout", entryMode: "touch" },
  { strategy: "breakout_daily", entryMode: "touch" },
  { strategy: "breakout_daily_elite", entryMode: "touch" },
  { strategy: "trend_pullback", entryMode: "confirmed" },
  { strategy: "pullback_small", entryMode: "confirmed" },
];
let backtestInFlight = false;

const decimal = (value: number) => value.toFixed(10).replace(/0+$/, "").replace(/\.$/, "");

function tradeRow(trade: BacktestTrade) {
  return {
    symbol: trade.symbol,
    strategy: trade.strategy,
    entryMode: trade.entryMode,
    score: trade.score,
    detectedAt: new Date(trade.detectedAt),
    entryTime: new Date(trade.entryTime),
    exitTime: new Date(trade.exitTime),
    entryPrice: decimal(trade.entryPrice),
    exitPrice: decimal(trade.exitPrice),
    stopLoss: decimal(trade.stopLoss),
    target1: decimal(trade.target1),
    target2: decimal(trade.target2),
    target3: decimal(trade.target3),
    outcome: trade.outcome,
    targetsHit: trade.targetsHit,
    rMultiple: trade.rMultiple,
    returnPercent: trade.returnPercent,
  };
}

export async function runBacktest(input: { markets: number; candles: number }) {
  if (backtestInFlight) {
    return { ...(await getLatestBacktest()), busy: true, ranAt: Date.now() };
  }
  backtestInFlight = true;
  try {
    const tickerResult = await getTickers();
    const universe = tickerResult.data
      .filter((ticker) => ticker.quoteVolume >= 5_000_000)
      .slice(0, input.markets);
    const datasets: Array<{ symbol: string; candles: Candle[]; dailyCandles: Candle[] }> = [];
    let feedErrors = 0;
    let cursor = 0;
    const workers = Array.from({ length: 6 }, async () => {
      while (cursor < universe.length) {
        const ticker = universe[cursor++];
        try {
          const [candleData, dailyData] = await Promise.all([
            getCandles(ticker.symbol, "4h", input.candles),
            getCandles(ticker.symbol, "1d", Math.ceil(input.candles / 6) + 80),
          ]);
          const candles = candleData.filter((candle) => candle.closeTime < Date.now());
          const dailyCandles = dailyData.filter((candle) => candle.closeTime < Date.now());
          if (candles.length >= 100 && dailyCandles.length >= 61) {
            datasets.push({ symbol: ticker.symbol, candles, dailyCandles });
          } else feedErrors += 1;
        } catch {
          feedErrors += 1;
        }
      }
    });
    await Promise.all(workers);
    if (!datasets.length) throw new Error("No historical spot candles are available right now. Try the backtest again shortly.");

    const groupId = randomUUID();
    const periodStart = new Date(Math.min(...datasets.map((dataset) => dataset.candles[0].openTime)));
    const periodEnd = new Date(Math.max(...datasets.map((dataset) => dataset.candles.at(-1)!.closeTime)));
    const recentCutoffs = datasets.map((dataset) => (
      dataset.candles[Math.floor(dataset.candles.length * 0.7)].openTime
    ));
    const recentPeriodStart = new Date(Math.min(...recentCutoffs));

    for (const variant of VARIANTS) {
      const results = datasets.map((dataset) => simulateMarket(
        dataset.symbol,
        dataset.candles,
        variant.entryMode,
        { feeBps: FEE_BPS, slippageBps: SLIPPAGE_BPS },
        { strategy: variant.strategy, dailyCandles: dataset.dailyCandles },
      ));
      const metrics = summariseBacktest(results);
      const recentMetrics = summariseBacktest(results.map((result, index) => ({
        ...result,
        trades: result.trades.filter((trade) => trade.detectedAt >= recentCutoffs[index]),
        setups: 0,
        cancelled: 0,
        openCount: 0,
        pendingCount: 0,
      })));
      const trades = results.flatMap((result) => result.trades);
      await createBacktestRun({
        groupId,
        strategy: variant.strategy,
        entryMode: variant.entryMode,
        marketsRequested: input.markets,
        candleLimit: input.candles,
        marketsScanned: datasets.length,
        feedErrors,
        feeBps: FEE_BPS,
        slippageBps: SLIPPAGE_BPS,
        periodStart,
        periodEnd,
        ...metrics,
        recentPeriodStart,
        recentTradesCount: recentMetrics.tradesCount,
        recentWinRate: recentMetrics.winRate,
        recentProfitFactor: recentMetrics.profitFactor,
        recentExpectancyR: recentMetrics.expectancyR,
        recentNetR: recentMetrics.netR,
        recentMaxDrawdownR: recentMetrics.maxDrawdownR,
      }, trades.map(tradeRow));
    }

    return { ...(await getBacktestGroup(groupId)), busy: false, ranAt: Date.now() };
  } finally {
    backtestInFlight = false;
  }
}
