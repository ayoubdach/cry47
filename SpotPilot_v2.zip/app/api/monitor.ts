import { runRadar } from "./radar";
import { runScan } from "./scanner";

const globalMonitor = globalThis as typeof globalThis & {
  __spotpilotMonitor?: ReturnType<typeof setInterval>;
  __spotpilotRadarMonitor?: ReturnType<typeof setInterval>;
};

export function startMonitor() {
  if (globalMonitor.__spotpilotMonitor) return;
  const initial = setTimeout(() => runScan().catch(() => undefined), 15_000);
  const initialRadar = setTimeout(() => {
    runRadar().then(() => runScan()).catch(() => undefined);
  }, 30_000);
  initial.unref();
  initialRadar.unref();

  globalMonitor.__spotpilotMonitor = setInterval(() => {
    runScan().catch(() => undefined);
  }, 90_000);
  globalMonitor.__spotpilotMonitor.unref();

  globalMonitor.__spotpilotRadarMonitor = setInterval(() => {
    runRadar().then(() => runScan()).catch(() => undefined);
  }, 15 * 60_000);
  globalMonitor.__spotpilotRadarMonitor.unref();
}
