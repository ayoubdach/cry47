import { desc, eq, inArray } from "drizzle-orm";
import {
  backtestRuns,
  backtestTrades,
  type BacktestRun,
  type BacktestTradeRow,
} from "@db/schema";
import { getDb } from "./connection";

export async function createBacktestRun(
  data: typeof backtestRuns.$inferInsert,
  trades: Array<Omit<typeof backtestTrades.$inferInsert, "id" | "runId" | "createdAt">>,
) {
  return getDb().transaction(async (tx) => {
    const [{ id }] = await tx.insert(backtestRuns).values(data).$returningId();
    if (trades.length) {
      await tx.insert(backtestTrades).values(trades.map((trade) => ({ ...trade, runId: id })));
    }
    return id;
  });
}

export async function getBacktestGroup(groupId: string): Promise<{
  groupId: string;
  runs: BacktestRun[];
  trades: BacktestTradeRow[];
}> {
  const db = getDb();
  const groupRuns = await db.select().from(backtestRuns).where(eq(backtestRuns.groupId, groupId)).orderBy(desc(backtestRuns.createdAt));
  const ids = groupRuns.map((run) => run.id);
  const trades = ids.length
    ? await db.select().from(backtestTrades).where(inArray(backtestTrades.runId, ids)).orderBy(desc(backtestTrades.exitTime))
    : [];
  return { groupId, runs: groupRuns, trades };
}

export async function getLatestBacktest() {
  const db = getDb();
  const history = await db.select().from(backtestRuns).orderBy(desc(backtestRuns.createdAt)).limit(12);
  const latestGroup = history[0]?.groupId;
  if (!latestGroup) return { groupId: null, runs: [], trades: [], history };
  const latest = await getBacktestGroup(latestGroup);
  return { ...latest, history };
}
