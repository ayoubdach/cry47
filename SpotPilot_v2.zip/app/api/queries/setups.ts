import { desc, eq } from "drizzle-orm";
import { alerts, setups, type InsertSetup } from "@db/schema";
import { getDb } from "./connection";

export async function listSetups() {
  return getDb().select().from(setups).orderBy(desc(setups.createdAt));
}

export async function listAlerts(limit = 40) {
  return getDb()
    .select({ alert: alerts, symbol: setups.symbol, strategy: setups.strategy })
    .from(alerts)
    .innerJoin(setups, eq(alerts.setupId, setups.id))
    .orderBy(desc(alerts.createdAt))
    .limit(limit);
}

export async function createSetup(data: InsertSetup) {
  const [{ id }] = await getDb().insert(setups).values(data).$returningId();
  return getDb().query.setups.findFirst({ where: eq(setups.id, id) });
}

export async function updateSetup(
  id: number,
  data: Partial<Pick<typeof setups.$inferInsert, "status" | "lastPrice" | "armedAt">>,
) {
  await getDb().update(setups).set({ ...data, updatedAt: new Date() }).where(eq(setups.id, id));
}

export async function addAlert(data: {
  setupId: number;
  kind: string;
  title: string;
  message: string;
}) {
  await getDb().insert(alerts).values(data);
}

export async function ensureStarterSetups() {
  const existing = await getDb().select({ id: setups.id }).from(setups).limit(1);
  if (existing.length) return;

  await getDb().insert(setups).values([
    {
      symbol: "UNIUSDT",
      breakout: "7.12",
      entryLow: "6.98",
      entryHigh: "7.06",
      stopLoss: "6.76",
      target1: "7.30",
      target2: "7.58",
      target3: "7.78",
      cancelBelow: "6.78",
      riskPercent: "0.50",
    },
    {
      symbol: "BTCUSDT",
      breakout: "80600",
      entryLow: "80100",
      entryHigh: "80400",
      stopLoss: "79180",
      target1: "82000",
      target2: "83400",
      target3: "84800",
      cancelBelow: "79200",
      riskPercent: "0.50",
    },
  ]);
}

export async function cancelSetup(id: number) {
  await updateSetup(id, { status: "cancelled" });
  return getDb().query.setups.findFirst({ where: eq(setups.id, id) });
}
