import type { Candle } from "./market";
import {
  analyseMarket,
  historicalTicker,
  isConfirmedRetest,
  scoreAccepted,
  zoneTouched,
  type EntryMode,
  type StrategyCandidate,
  type StrategyVariant,
} from "./strategy";
import { analyseTrendPullback, isDailyUptrend } from "./trend-strategy";

export type BacktestTrade = {
  symbol: string;
  strategy: StrategyVariant;
  entryMode: EntryMode;
  score: number;
  detectedAt: number;
  entryTime: number;
  exitTime: number;
  entryPrice: number;
  exitPrice: number;
  stopLoss: number;
  target1: number;
  target2: number;
  target3: number;
  outcome: "completed" | "stopped" | "timed_out";
  targetsHit: number;
  rMultiple: number;
  returnPercent: number;
};

export type SimulationResult = {
  trades: BacktestTrade[];
  setups: number;
  cancelled: number;
  openCount: number;
  pendingCount: number;
};

export type BacktestMetrics = {
  tradesCount: number;
  wins: number;
  losses: number;
  winRate: number;
  profitFactor: number | null;
  expectancyR: number;
  netR: number;
  maxDrawdownR: number;
  setups: number;
  cancelled: number;
  openCount: number;
  pendingCount: number;
};

type Options = {
  feeBps: number;
  slippageBps: number;
};

export type SimulationConfig = {
  strategy?: StrategyVariant;
  dailyCandles?: Candle[];
};

type OpenTrade = {
  candidate: StrategyCandidate;
  detectedAt: number;
  entryTime: number;
  entryIndex: number;
  plannedEntry: number;
  effectiveEntry: number;
  entryFee: number;
  initialRisk: number;
  remaining: number;
  stage: number;
  realizedPnl: number;
  exitValue: number;
};

type InternalTrade = OpenTrade;

const TARGET_PART = 1 / 3;
const SMALL_TARGET_TIMEOUT_CANDLES = 30; // Five days on 4H candles.

export function simulateMarket(
  symbol: string,
  inputCandles: Candle[],
  entryMode: EntryMode,
  options: Options,
  config: SimulationConfig = {},
): SimulationResult {
  const strategy = config.strategy ?? "breakout";
  const dailyCandles = config.dailyCandles ?? [];
  const candles = inputCandles
    .filter((candle) => candle.closeTime < Date.now())
    .sort((a, b) => a.openTime - b.openTime);
  const trades: BacktestTrade[] = [];
  let pending: { candidate: StrategyCandidate; detectedAt: number; detectedIndex: number } | null = null;
  let open: OpenTrade | null = null;
  let setups = 0;
  let cancelled = 0;
  let cooldownUntil = -1;
  const feeRate = options.feeBps / 10_000;
  const slippageRate = options.slippageBps / 10_000;

  const closeTrade = (trade: OpenTrade, outcome: BacktestTrade["outcome"], exitTime: number) => {
    const netPnl = trade.realizedPnl - trade.entryFee;
    trades.push({
      symbol,
      strategy,
      entryMode,
      score: trade.candidate.score,
      detectedAt: trade.detectedAt,
      entryTime: trade.entryTime,
      exitTime,
      entryPrice: trade.effectiveEntry,
      exitPrice: trade.exitValue,
      stopLoss: trade.candidate.stopLoss,
      target1: trade.candidate.target1,
      target2: trade.candidate.target2,
      target3: trade.candidate.target3,
      outcome,
      targetsHit: trade.stage,
      rMultiple: netPnl / trade.initialRisk,
      returnPercent: (netPnl / trade.effectiveEntry) * 100,
    });
    open = null;
  };

  // The six-candle cooldown starts at the exit candle, not the entry candle.

  const exitPortion = (trade: InternalTrade, portion: number, rawPrice: number) => {
    const exitPrice = rawPrice * (1 - slippageRate);
    trade.realizedPnl += portion * (exitPrice - trade.effectiveEntry - exitPrice * feeRate);
    trade.exitValue += portion * exitPrice;
    trade.remaining = Math.max(0, trade.remaining - portion);
  };

  const manageTrade = (trade: InternalTrade, candle: Candle, allowTargets: boolean) => {
    const levels = trade.candidate;
    if (candle.low <= levels.stopLoss) {
      const gapAwareStop = candle.open < levels.stopLoss ? candle.open : levels.stopLoss;
      exitPortion(trade, trade.remaining, gapAwareStop);
      closeTrade(trade, "stopped", candle.closeTime);
      return true;
    }
    if (!allowTargets) return false;

    const targets = [levels.target1, levels.target2, levels.target3];
    while (trade.stage < 3 && candle.high >= targets[trade.stage]) {
      exitPortion(trade, TARGET_PART, targets[trade.stage]);
      trade.stage += 1;
      if (trade.stage === 3) {
        closeTrade(trade, "completed", candle.closeTime);
        return true;
      }
    }
    return false;
  };

  for (let index = 60; index < candles.length; index += 1) {
    const candle = candles[index];

    if (open) {
      const trade = open as InternalTrade;
      const justEntered = trade.entryIndex === index;
      manageTrade(trade, candle, !justEntered);
      if (open && strategy === "pullback_small" && index - trade.entryIndex >= SMALL_TARGET_TIMEOUT_CANDLES) {
        exitPortion(trade, trade.remaining, candle.close);
        closeTrade(trade, "timed_out", candle.closeTime);
      }
      if (!open) cooldownUntil = index + 6;
      continue;
    }

    if (pending) {
      const levels = pending.candidate;
      if (pending.candidate.status === "waiting") {
        const expired = index - pending.detectedIndex > 18;
        if (candle.close < levels.cancelBelow || expired || candle.low <= levels.stopLoss) {
          pending = null;
          cancelled += 1;
          cooldownUntil = index + 6;
          continue;
        }
        if (candle.close > levels.breakout) {
          pending.candidate.status = "armed";
          // A confirmation candle must come after the breakout candle.
          continue;
        }
        continue;
      }

      if ((strategy === "breakout_daily" || strategy === "breakout_daily_elite")
        && !isDailyUptrend(dailyCandles, candle.openTime)) {
        pending = null;
        cancelled += 1;
        cooldownUntil = index + 6;
        continue;
      }

      let plannedEntry: number;
      let entryTime = candle.closeTime;
      let candidate = pending.candidate;

      if (strategy === "trend_pullback" || strategy === "pullback_small") {
        // The confirmation candle is already closed. Fill at the next open,
        // unless the market gaps through the invalidation structure first.
        if (candle.open <= levels.cancelBelow || candle.open <= levels.stopLoss) {
          pending = null;
          cancelled += 1;
          cooldownUntil = index + 6;
          continue;
        }
        plannedEntry = candle.open;
        entryTime = candle.openTime;
        const risk = plannedEntry - levels.stopLoss;
        candidate = {
          ...levels,
          target1: strategy === "pullback_small" ? plannedEntry * 1.04 : plannedEntry + risk,
          target2: strategy === "pullback_small" ? plannedEntry * 1.07 : plannedEntry + 2 * risk,
          target3: strategy === "pullback_small" ? plannedEntry * 1.08 : plannedEntry + 3 * risk,
        };
      } else {
        if (candle.close < levels.cancelBelow || candle.low <= levels.stopLoss) {
          pending = null;
          cancelled += 1;
          cooldownUntil = index + 6;
          continue;
        }
        const touched = zoneTouched(candle, levels);
        const confirmed = entryMode === "confirmed" && isConfirmedRetest(candle, levels);
        const shouldEnter = entryMode === "touch" ? touched : confirmed;
        if (!shouldEnter) continue;
        if (candle.close >= levels.target1) {
          pending = null;
          cancelled += 1;
          cooldownUntil = index + 6;
          continue;
        }
        plannedEntry = entryMode === "touch"
          ? (levels.entryLow + levels.entryHigh) / 2
          : candle.close;
      }

      const effectiveEntry = plannedEntry * (1 + slippageRate);
      const stopWithSlippage = candidate.stopLoss * (1 - slippageRate);
      const initialRisk = effectiveEntry - stopWithSlippage;
      if (!(initialRisk > 0) || plannedEntry >= candidate.target1) {
        pending = null;
        cancelled += 1;
        continue;
      }
      const detectedAt = pending.detectedAt;
      open = {
        candidate,
        detectedAt,
        entryTime,
        entryIndex: index,
        plannedEntry,
        effectiveEntry,
        entryFee: effectiveEntry * feeRate,
        initialRisk,
        remaining: 1,
        stage: 0,
        realizedPnl: 0,
        exitValue: 0,
      } satisfies InternalTrade;
      pending = null;

      // Stops are valid on a touch-entry candle. Targets are deliberately
      // delayed until a later candle because 4H OHLC cannot prove the path.
      manageTrade(open as InternalTrade, candle, false);
      if (!open) cooldownUntil = index + 6;
      continue;
    }

    if (index <= cooldownUntil) continue;
    const available = candles.slice(0, index + 1);
    const now = candle.closeTime + 1;
    const ticker = { ...historicalTicker(available), symbol };
    let candidate: StrategyCandidate | null = null;
    if (strategy === "trend_pullback" || strategy === "pullback_small") {
      candidate = analyseTrendPullback(ticker, available, dailyCandles, now);
      if (candidate && strategy === "pullback_small") {
        candidate = {
          ...candidate,
          strategy,
          reason: `4% / 7% / 8% targets • five-day time exit • ${candidate.reason}`,
        };
      }
    } else {
      const breakout = analyseMarket(ticker, available, now);
      if (breakout && (strategy === "breakout" || isDailyUptrend(dailyCandles, now))) {
        candidate = strategy === "breakout_daily" || strategy === "breakout_daily_elite"
          ? { ...breakout, strategy, reason: `Daily uptrend confirmed • ${breakout.reason}` }
          : breakout;
        if (candidate && !scoreAccepted(candidate.score, strategy)) candidate = null;
      }
    }
    if (!candidate) continue;
    setups += 1;
    pending = { candidate, detectedAt: candle.closeTime, detectedIndex: index };
  }

  return {
    trades,
    setups,
    cancelled,
    openCount: open ? 1 : 0,
    pendingCount: pending ? 1 : 0,
  };
}

export function summariseBacktest(results: SimulationResult[]): BacktestMetrics {
  const trades = results
    .flatMap((result) => result.trades)
    .sort((a, b) => a.exitTime - b.exitTime || a.symbol.localeCompare(b.symbol));
  const wins = trades.filter((trade) => trade.rMultiple > 0).length;
  const losses = trades.filter((trade) => trade.rMultiple < 0).length;
  const grossWins = trades.filter((trade) => trade.rMultiple > 0).reduce((sum, trade) => sum + trade.rMultiple, 0);
  const grossLosses = Math.abs(trades.filter((trade) => trade.rMultiple < 0).reduce((sum, trade) => sum + trade.rMultiple, 0));
  const netR = trades.reduce((sum, trade) => sum + trade.rMultiple, 0);
  let equity = 0;
  let peak = 0;
  let maxDrawdownR = 0;
  for (const trade of trades) {
    equity += trade.rMultiple;
    peak = Math.max(peak, equity);
    maxDrawdownR = Math.max(maxDrawdownR, peak - equity);
  }

  return {
    tradesCount: trades.length,
    wins,
    losses,
    winRate: trades.length ? (wins / trades.length) * 100 : 0,
    profitFactor: grossLosses > 0 ? grossWins / grossLosses : null,
    expectancyR: trades.length ? netR / trades.length : 0,
    netR,
    maxDrawdownR,
    setups: results.reduce((sum, result) => sum + result.setups, 0),
    cancelled: results.reduce((sum, result) => sum + result.cancelled, 0),
    openCount: results.reduce((sum, result) => sum + result.openCount, 0),
    pendingCount: results.reduce((sum, result) => sum + result.pendingCount, 0),
  };
}
