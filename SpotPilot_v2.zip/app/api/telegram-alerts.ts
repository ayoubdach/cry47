import type { Setup } from "@db/schema";

const num = (value: string | number | null) => Number(value ?? 0);
const money = (value: string | number | null) => num(value).toLocaleString("en-US", { maximumSignificantDigits: 6 });
const esc = (text: string) => text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
const pct = (value: number, base: number) => `${value >= base ? "+" : ""}${((value / base - 1) * 100).toFixed(1)}%`;

export function strategyLabel(strategy: string) {
  return strategy === "breakout_daily_elite" ? "ELITE BREAKOUT" : "BREAKOUT RADAR";
}

/** Statuses that are worth a phone buzz. Everything else stays on the dashboard only. */
export const TELEGRAM_STATUSES = ["active", "tp1", "tp2", "completed", "stopped"] as const;
export function shouldSendTelegram(status: string) {
  return (TELEGRAM_STATUSES as readonly string[]).includes(status);
}

function badge(setup: Setup) {
  const elite = setup.strategy === "breakout_daily_elite";
  return `${elite ? "⭐ Elite" : "📡 Radar"}${setup.source === "radar" ? ` · Score ${setup.score}/99` : ""}`;
}

function ladder(reached: number) {
  return [1, 2, 3].map((n) => `TP${n} ${reached >= n ? "✅" : "⬜"}`).join("   ");
}

/**
 * Short, scannable paper-trade alert (Telegram HTML). `setup` is the state BEFORE the transition,
 * so its status tells us how many targets were already reached.
 * Never include credentials in this payload.
 */
export function formatTradeTelegram(setup: Setup, status: string, lastPrice: number) {
  const pair = esc(setup.symbol.replace("USDT", "/USDT"));
  const stop = num(setup.stopLoss);
  const [tp1, tp2, tp3] = [num(setup.target1), num(setup.target2), num(setup.target3)];
  const reachedBefore = setup.status === "tp2" ? 2 : setup.status === "tp1" ? 1 : 0;
  const foot = "📝 <i>Paper trade · no real orders</i>";

  if (status === "active") {
    const levels = [
      `Entry  ${money(lastPrice)}`,
      `Stop   ${money(stop)}  ${pct(stop, lastPrice)}`,
      `TP1    ${money(tp1)}  ${pct(tp1, lastPrice)}`,
      `TP2    ${money(tp2)}  ${pct(tp2, lastPrice)}`,
      `TP3    ${money(tp3)}  ${pct(tp3, lastPrice)}`,
    ].join("\n");
    return [
      `🟢 <b>ENTRY · ${pair}</b>`,
      badge(setup),
      "",
      `<pre>${levels}</pre>`,
      `Risk ${Number(setup.riskPercent).toFixed(2)}% of paper account`,
      foot,
    ].join("\n");
  }

  if (status === "tp1" || status === "tp2") {
    const n = status === "tp1" ? 1 : 2;
    const next = n === 1 ? `TP2 ${money(tp2)}` : `TP3 ${money(tp3)}`;
    return [
      `🎯 <b>TARGET ${n} HIT · ${pair}</b>`,
      badge(setup),
      "",
      `<pre>${ladder(n)}</pre>`,
      `TP${n} ${money(n === 1 ? tp1 : tp2)} reached · price ${money(lastPrice)}`,
      `Next: ${next} · Stop ${money(stop)}`,
      foot,
    ].join("\n");
  }

  if (status === "completed") {
    return [
      `🏆 <b>ALL TARGETS HIT · ${pair}</b>`,
      badge(setup),
      "",
      `<pre>${ladder(3)}</pre>`,
      `TP3 ${money(tp3)} reached · price ${money(lastPrice)}`,
      "Trade closed ✅",
      foot,
    ].join("\n");
  }

  // stopped
  return [
    `🔴 <b>STOP HIT · ${pair}</b>`,
    badge(setup),
    "",
    `<pre>${ladder(reachedBefore)}</pre>`,
    `Stop ${money(stop)} triggered · price ${money(lastPrice)}`,
    reachedBefore ? `Closed after TP${reachedBefore}` : "Closed at a loss",
    foot,
  ].join("\n");
}
