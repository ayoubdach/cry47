import type { Setup } from "@db/schema";
import { addAlert, cancelSetup, createSetup, listSetups } from "./queries/setups";
import { getCandles, getTickers, type Ticker } from "./market";
import { analyseMarket, scoreAccepted, type StrategyCandidate, type StrategyVariant } from "./strategy";
import { isDailyUptrend } from "./trend-strategy";
import { strategyLabel } from "./telegram-alerts";

const RADAR_LIMIT = 20;
const ELITE_RADAR_LIMIT = 8;
const UNIVERSE_SIZE = 120;
const MAX_AUTO_AGE_MS = 72 * 60 * 60 * 1000;
const RADAR_ENTRY_MODE = "touch";
const ELITE_STRATEGY: StrategyVariant = "breakout_daily_elite";
const money = (value: number) => value.toLocaleString("en-US", { maximumFractionDigits: 8 });
const decimal = (value: number) => value.toFixed(10).replace(/0+$/, "").replace(/\.$/, "");
const isOpen = (setup: Setup) => ["waiting", "armed", "active", "tp1", "tp2"].includes(setup.status);

async function discover(tickers: Ticker[]) {
  const universe = tickers.filter((ticker) => ticker.quoteVolume >= 5_000_000).slice(0, UNIVERSE_SIZE);
  const candidates: StrategyCandidate[] = [];
  let errors = 0;
  let cursor = 0;
  const workers = Array.from({ length: 8 }, async () => {
    while (cursor < universe.length) {
      const ticker = universe[cursor++];
      try {
        const candles = await getCandles(ticker.symbol, "4h", 80);
        const candidate = analyseMarket(ticker, candles);
        if (!candidate) continue;
        candidates.push(candidate);
        if (scoreAccepted(candidate.score, ELITE_STRATEGY)) {
          const daily = await getCandles(ticker.symbol, "1d", 80);
          if (isDailyUptrend(daily, Date.now())) {
            candidates.push({
              ...candidate,
              strategy: ELITE_STRATEGY,
              reason: `Daily EMA20 above rising EMA50 • ${candidate.reason}`,
            });
          }
        }
      } catch {
        errors += 1;
      }
    }
  });
  await Promise.all(workers);
  return {
    candidates: candidates.sort((a, b) => b.score - a.score || a.symbol.localeCompare(b.symbol)),
    scanned: universe.length,
    errors,
  };
}

let radarInFlight = false;

export async function runRadar() {
  if (radarInFlight) return { scanned: 0, candidates: 0, added: 0, eliteAdded: 0, errors: 0, expired: 0, opportunities: [] as Setup[], ranAt: Date.now(), busy: true };
  radarInFlight = true;
  try {
    const [tickerResult, existingBefore] = await Promise.all([getTickers(), listSetups()]);
    const discovery = await discover(tickerResult.data);
    let expired = 0;
    for (const setup of existingBefore) {
      if (setup.source === "radar" && setup.status === "waiting" && Date.now() - setup.createdAt.getTime() > MAX_AUTO_AGE_MS) {
        await cancelSetup(setup.id);
        const title = `${setup.symbol.replace("USDT", "/USDT")} ${strategyLabel(setup.strategy)} setup expired`;
        const message = "72 hours passed without a confirmed 4H breakout. The radar released this slot for a fresher structure.";
        await addAlert({ setupId: setup.id, kind: "cancelled", title, message });
        expired += 1;
      }
    }

    const existing = expired ? await listSetups() : existingBefore;
    const openKeys = new Set(existing.filter((setup) => setup.source === "radar" && isOpen(setup)).map((setup) => `${setup.strategy}:${setup.symbol}`));
    const cooldownKeys = new Set(existing.filter((setup) =>
      setup.source === "radar"
      && ["completed", "stopped", "cancelled"].includes(setup.status)
      && Date.now() - setup.updatedAt.getTime() < 24 * 60 * 60 * 1000
    ).map((setup) => `${setup.strategy}:${setup.symbol}`));
    const selected: StrategyCandidate[] = [];
    for (const strategy of ["breakout", ELITE_STRATEGY] as const) {
      const limit = strategy === ELITE_STRATEGY ? ELITE_RADAR_LIMIT : RADAR_LIMIT;
      const open = existing.filter((setup) => setup.source === "radar" && setup.strategy === strategy && isOpen(setup)).length;
      const slots = Math.max(0, limit - open);
      selected.push(...discovery.candidates.filter((candidate) =>
        candidate.strategy === strategy
        && !openKeys.has(`${strategy}:${candidate.symbol}`)
        && !cooldownKeys.has(`${strategy}:${candidate.symbol}`)
      ).slice(0, slots));
    }
    selected.sort((a, b) => Number(b.strategy === ELITE_STRATEGY) - Number(a.strategy === ELITE_STRATEGY) || b.score - a.score);
    const opportunities: Setup[] = [];

    for (const candidate of selected) {
      const created = await createSetup({
        symbol: candidate.symbol,
        breakout: decimal(candidate.breakout),
        entryLow: decimal(candidate.entryLow),
        entryHigh: decimal(candidate.entryHigh),
        stopLoss: decimal(candidate.stopLoss),
        target1: decimal(candidate.target1),
        target2: decimal(candidate.target2),
        target3: decimal(candidate.target3),
        cancelBelow: decimal(candidate.cancelBelow),
        riskPercent: "0.50",
        source: "radar",
        strategy: candidate.strategy,
        entryMode: RADAR_ENTRY_MODE,
        score: candidate.score,
        reason: candidate.reason,
        status: candidate.status,
        armedAt: candidate.status === "armed" ? new Date() : null,
        lastPrice: decimal(candidate.lastPrice),
      });
      if (!created) continue;
      opportunities.push(created);
      const pair = created.symbol.replace("USDT", "/USDT");
      const elite = created.strategy === ELITE_STRATEGY;
      const title = `${pair} joined ${strategyLabel(created.strategy)}`;
      const message = `Score ${created.score}/99. ${created.reason}. Entry remains conditional on a valid breakout and retest${elite ? ", with the Daily trend checked again before entry" : ""}.`;
      await addAlert({ setupId: created.id, kind: "discovered", title, message });
      if (created.status === "armed") {
        const breakoutMessage = `4H closed above ${money(Number(created.breakout))}. Wait for the ${money(Number(created.entryLow))}–${money(Number(created.entryHigh))} retest; do not chase.${elite ? " Daily trend must still be valid at entry." : ""}`;
        await addAlert({
          setupId: created.id,
          kind: "breakout",
          title: `${pair} ${elite ? "Elite " : ""}breakout confirmed`,
          message: breakoutMessage,
        });
      }
    }

    const eliteAdded = opportunities.filter((setup) => setup.strategy === ELITE_STRATEGY).length;
    return { scanned: discovery.scanned, candidates: discovery.candidates.length, added: opportunities.length, eliteAdded, errors: discovery.errors, expired, opportunities, ranAt: Date.now(), busy: false };
  } finally {
    radarInFlight = false;
  }
}
