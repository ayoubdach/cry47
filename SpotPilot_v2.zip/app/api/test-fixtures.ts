import type { Candle, Ticker } from "./market";

export const FOUR_HOURS = 4 * 60 * 60 * 1000;
export const DAY = 24 * 60 * 60 * 1000;

export function candle(
  index: number,
  open: number,
  high: number,
  low: number,
  close: number,
  volume = 1_000_000,
): Candle {
  return {
    openTime: index * FOUR_HOURS,
    closeTime: (index + 1) * FOUR_HOURS - 1,
    open,
    high,
    low,
    close,
    volume,
    quoteVolume: close * volume,
  };
}

export function marketCandles(withBreakout = false): Candle[] {
  return Array.from({ length: withBreakout ? 61 : 60 }, (_, index) => {
    const previousClose = index ? 100 + (index - 1) * 0.1 : 99.9;
    let close = 100 + index * 0.1;
    if (withBreakout && index === 60) close = 106.8;
    return candle(
      index,
      previousClose,
      Math.max(previousClose, close) + 0.5,
      Math.min(previousClose, close) - 0.5,
      close,
    );
  });
}

export function dailyCandlesEnding(endTime: number, count = 70, rising = true): Candle[] {
  return Array.from({ length: count }, (_, index) => {
    const openTime = endTime - (count - index) * DAY;
    const open = rising ? 80 + index * 0.5 : 130 - index * 0.5;
    const close = rising ? open + 0.4 : open - 0.4;
    return {
      openTime,
      closeTime: openTime + DAY - 1,
      open,
      high: Math.max(open, close) + 0.5,
      low: Math.min(open, close) - 0.5,
      close,
      volume: 1_000_000,
      quoteVolume: close * 1_000_000,
    };
  });
}

export function testTicker(symbol = "TESTUSDT"): Ticker {
  return {
    symbol,
    price: 106.8,
    changePercent: 2,
    high: 108,
    low: 100,
    quoteVolume: 600_000_000,
  };
}
