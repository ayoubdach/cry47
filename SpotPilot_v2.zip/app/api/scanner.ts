import type { SetupStatus } from "@contracts/constants";
import type { Setup } from "@db/schema";
import { addAlert, listSetups, updateSetup } from "./queries/setups";
import { getCandles, getTickers, type Candle } from "./market";
import { isConfirmedRetest } from "./strategy";
import { isDailyUptrend } from "./trend-strategy";
import { notifyTelegram } from "./notify";
import { formatTradeTelegram, shouldSendTelegram } from "./telegram-alerts";

let scanInFlight = false;

const price = (value: string | number | null) => Number(value ?? 0);
const money = (value: number) => value.toLocaleString("en-US", { maximumFractionDigits: 8 });
const isElite = (setup: Setup) => setup.strategy === "breakout_daily_elite";

export type PriceRange = { high: number; low: number };

/** Highest/lowest traded price since the setup was last checked, so wicks between polls are not missed. */
async function movementSince(setup: Setup, lastPrice: number): Promise<PriceRange> {
  const since = setup.updatedAt.getTime();
  const minutes = Math.ceil((Date.now() - since) / 60_000) + 1;
  const candles = await getCandles(setup.symbol, "1m", Math.min(Math.max(minutes, 2), 500));
  const recent = candles.filter((candle) => candle.closeTime >= since);
  return {
    high: Math.max(lastPrice, ...recent.map((candle) => candle.high)),
    low: Math.min(lastPrice, ...recent.map((candle) => candle.low)),
  };
}

export function nextStatus(setup: Setup, lastPrice: number, closed4h: Candle, range?: PriceRange): SetupStatus | null {
  const levels = {
    entryLow: price(setup.entryLow),
    entryHigh: price(setup.entryHigh),
    stopLoss: price(setup.stopLoss),
    target1: price(setup.target1),
    target2: price(setup.target2),
    target3: price(setup.target3),
    cancelBelow: price(setup.cancelBelow),
    breakout: price(setup.breakout),
  };
  const status = setup.status;

  if (status === "waiting") {
    if (closed4h.close < levels.cancelBelow) return "cancelled";
    if (closed4h.close > levels.breakout) return "armed";
    return null;
  }
  if (status === "armed") {
    if (closed4h.close < levels.cancelBelow || lastPrice <= levels.stopLoss) return "cancelled";
    if (setup.entryMode === "confirmed") {
      const isLaterCandle = !setup.armedAt || closed4h.closeTime > setup.armedAt.getTime();
      if (
        isLaterCandle
        && isConfirmedRetest(closed4h, levels)
        && lastPrice > levels.stopLoss
        && lastPrice < levels.target1
      ) return "active";
      return null;
    }
    if (lastPrice >= levels.entryLow && lastPrice <= levels.entryHigh) return "active";
    return null;
  }
  if (["active", "tp1", "tp2"].includes(status)) {
    // Stop is checked first: if stop and a target fall inside the same window, order is unknowable, so assume the loss.
    const low = Math.min(lastPrice, range?.low ?? lastPrice);
    const high = Math.max(lastPrice, range?.high ?? lastPrice);
    if (low <= levels.stopLoss) return "stopped";
    if (high >= levels.target3) return "completed";
    if (status !== "tp2" && high >= levels.target2) return "tp2";
    if (status === "active" && high >= levels.target1) return "tp1";
  }
  return null;
}

function alertCopy(setup: Setup, status: SetupStatus, lastPrice: number) {
  const pair = setup.symbol.replace("USDT", "/USDT");
  const label = isElite(setup) ? "Elite " : "";
  const entry = `${money(price(setup.entryLow))}–${money(price(setup.entryHigh))}`;
  const confirmation = setup.entryMode === "confirmed"
    ? `Bullish 4H retest confirmation closed above ${money(price(setup.entryHigh))}. Paper entry at ${money(lastPrice)}. Stop ${money(price(setup.stopLoss))}.`
    : `Price ${money(lastPrice)} is inside ${entry}. Paper setup active. Stop ${money(price(setup.stopLoss))}.${isElite(setup) ? " Daily uptrend rechecked at entry." : ""}`;
  const copy: Record<string, [string, string, string]> = {
    armed: ["breakout", `${pair} ${label}breakout confirmed`, `4H closed above ${money(price(setup.breakout))}. Wait for the ${entry} retest${setup.entryMode === "confirmed" ? " and bullish 4H confirmation" : ""}; do not chase.${isElite(setup) ? " Daily trend must still be valid at entry." : ""}`],
    active: ["entry", `${pair} ${label}paper entry confirmed`, confirmation],
    tp1: ["target", `${pair} ${label}target 1 reached`, `TP1 ${money(price(setup.target1))} reached at ${money(lastPrice)}.`],
    tp2: ["target", `${pair} ${label}target 2 reached`, `TP2 ${money(price(setup.target2))} reached at ${money(lastPrice)}.`],
    completed: ["completed", `${pair} ${label}setup completed`, `Final target ${money(price(setup.target3))} reached at ${money(lastPrice)}.`],
    stopped: ["stopped", `${pair} ${label}stop hit`, `Stop ${money(price(setup.stopLoss))} triggered at ${money(lastPrice)}. Loss recorded.`],
    cancelled: ["cancelled", `${pair} ${label}setup cancelled`, `Structure invalidated below ${money(price(setup.cancelBelow))}. No entry is valid.`],
  };
  return copy[status];
}

async function transition(setup: Setup, status: SetupStatus, lastPrice: number, messageOverride?: string) {
  await updateSetup(setup.id, {
    status,
    lastPrice: String(lastPrice),
    ...(status === "armed" ? { armedAt: new Date() } : {}),
  });
  const [kind, title, message] = alertCopy(setup, status, lastPrice);
  await addAlert({ setupId: setup.id, kind, title, message: messageOverride ?? message });
  // Dashboard keeps every event; Telegram only gets entries, targets and stops.
  if (shouldSendTelegram(status)) await notifyTelegram(formatTradeTelegram(setup, status, lastPrice));
}

export async function runScan() {
  if (scanInFlight) return { scanned: 0, transitions: 0, errors: 0, ranAt: Date.now(), busy: true };
  scanInFlight = true;
  let transitions = 0;
  let errors = 0;
  try {
    const [setups, tickerResult] = await Promise.all([listSetups(), getTickers()]);
    const prices = new Map(tickerResult.data.map((item) => [item.symbol, item.price]));
    for (const setup of setups) {
      if (!["waiting", "armed", "active", "tp1", "tp2"].includes(setup.status)) continue;
      try {
        const lastPrice = prices.get(setup.symbol);
        if (!lastPrice) continue;
        const candles = await getCandles(setup.symbol, "4h", 12);
        const daily = isElite(setup) && ["waiting", "armed"].includes(setup.status)
          ? await getCandles(setup.symbol, "1d", 80)
          : [];
        const dailyTrend = isElite(setup) ? isDailyUptrend(daily, Date.now()) : true;
        const closed = candles.filter((candle) => candle.closeTime < Date.now());
        const closed4h = closed.at(-1);
        if (!closed4h) continue;
        let current = setup;
        // Wick-aware range only for open positions; an entry candle never earns target credit.
        let range = ["active", "tp1", "tp2"].includes(setup.status)
          ? await movementSince(setup, lastPrice)
          : undefined;
        for (let step = 0; step < 3; step += 1) {
          if (current.status === "armed" && isElite(current) && !dailyTrend) {
            await transition(current, "cancelled", lastPrice, "Daily uptrend failed the Elite entry recheck. Setup cancelled before entry; no paper position opened.");
            transitions += 1;
            break;
          }
          const status = nextStatus(current, lastPrice, closed4h, range);
          if (!status) break;
          await transition(current, status, lastPrice);
          transitions += 1;
          if (["waiting", "armed"].includes(current.status)) range = undefined;
          current = {
            ...current,
            status,
            lastPrice: String(lastPrice),
            ...(status === "armed" ? { armedAt: new Date() } : {}),
          };
        }
        await updateSetup(setup.id, { lastPrice: String(lastPrice) });
      } catch {
        errors += 1;
      }
    }
    return { scanned: setups.length, transitions, errors, ranAt: Date.now(), busy: false };
  } finally {
    scanInFlight = false;
  }
}
