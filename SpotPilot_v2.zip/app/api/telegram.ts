export function telegramConfig() {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_CHAT_ID;
  return {
    configured: Boolean(token && chatId),
    chatLabel: chatId ? `Chat •••${chatId.slice(-4)}` : "No chat configured",
  };
}

export async function sendTelegram(text: string) {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_CHAT_ID;
  if (!token || !chatId) return { delivered: false, reason: "not_configured" as const };

  const response = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ chat_id: chatId, text, parse_mode: "HTML", disable_web_page_preview: true }),
    signal: AbortSignal.timeout(9000),
  });
  if (!response.ok) throw new Error(`Telegram delivery failed (${response.status})`);
  return { delivered: true, reason: "delivered" as const };
}
