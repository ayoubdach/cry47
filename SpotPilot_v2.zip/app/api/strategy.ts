import type { SetupStatus } from "@contracts/constants";
import type { Candle, Ticker } from "./market";

export type EntryMode = "touch" | "confirmed";
export type StrategyVariant = "breakout" | "breakout_daily" | "breakout_daily_elite" | "trend_pullback" | "pullback_small";

export function scoreAccepted(score: number, strategy: StrategyVariant) {
  return strategy !== "breakout_daily_elite" || score >= 85;
}

export type StrategyLevels = {
  breakout: number;
  entryLow: number;
  entryHigh: number;
  stopLoss: number;
  target1: number;
  target2: number;
  target3: number;
  cancelBelow: number;
};

export type StrategyCandidate = StrategyLevels & {
  symbol: string;
  strategy: StrategyVariant;
  score: number;
  reason: string;
  status: Extract<SetupStatus, "waiting" | "armed">;
  lastPrice: number;
  atr: number;
  volumeRatio: number;
};

export function ema(values: number[], period: number) {
  if (!values.length) return 0;
  const smoothing = 2 / (period + 1);
  return values.slice(1).reduce(
    (average, value) => value * smoothing + average * (1 - smoothing),
    values[0],
  );
}

export function average(values: number[]) {
  return values.reduce((sum, value) => sum + value, 0) / Math.max(values.length, 1);
}

export function zoneTouched(candle: Candle, levels: Pick<StrategyLevels, "entryLow" | "entryHigh">) {
  return candle.low <= levels.entryHigh && candle.high >= levels.entryLow;
}

export function isConfirmedRetest(candle: Candle, levels: Pick<StrategyLevels, "entryLow" | "entryHigh">) {
  return zoneTouched(candle, levels)
    && candle.close > levels.entryHigh
    && candle.close > candle.open;
}

export function historicalTicker(candles: Candle[]): Ticker {
  const closed = candles.filter((candle) => candle.closeTime < Number.MAX_SAFE_INTEGER);
  const last = closed.at(-1)!;
  const recent = closed.slice(-6);
  const first = recent[0] ?? last;
  return {
    symbol: "",
    price: last.close,
    changePercent: first.open > 0 ? ((last.close - first.open) / first.open) * 100 : 0,
    high: Math.max(...recent.map((candle) => candle.high)),
    low: Math.min(...recent.map((candle) => candle.low)),
    quoteVolume: recent.reduce((sum, candle) => sum + candle.quoteVolume, 0),
  };
}

/**
 * Builds a candidate using only candles closed at `now`. The resistance window
 * deliberately excludes the two latest candles so the breakout candle cannot
 * define its own resistance level.
 */
export function analyseMarket(ticker: Ticker, candles: Candle[], now = Date.now()): StrategyCandidate | null {
  const closed = candles.filter((candle) => candle.closeTime < now);
  if (closed.length < 60) return null;
  const last = closed.at(-1)!;
  const previous = closed.at(-2)!;
  const resistanceCandles = closed.slice(-22, -2);
  if (resistanceCandles.length < 20) return null;
  const breakout = Math.max(...resistanceCandles.map((candle) => candle.high));
  const trueRanges = closed.slice(-15).map((candle, index, recent) => {
    const priorClose = index === 0 ? closed.at(-16)!.close : recent[index - 1].close;
    return Math.max(
      candle.high - candle.low,
      Math.abs(candle.high - priorClose),
      Math.abs(candle.low - priorClose),
    );
  });
  const atr = average(trueRanges);
  if (!(atr > 0) || !(breakout > 0) || atr / last.close < 0.001 || ticker.quoteVolume < 5_000_000) return null;

  const freshBreakout = previous.close <= breakout
    && last.close > breakout
    && last.close <= breakout + 1.2 * atr;
  const nearBreakout = last.close <= breakout
    && breakout - last.close <= Math.min(3 * atr, breakout * 0.08);
  if (!freshBreakout && !nearBreakout) return null;

  const entryHigh = breakout - 0.1 * atr;
  const entryLow = breakout - 0.85 * atr;
  const stopLoss = entryLow - 1.1 * atr;
  const cancelBelow = entryLow - 0.3 * atr;
  const entryMid = (entryLow + entryHigh) / 2;
  const risk = entryMid - stopLoss;
  const target1 = entryMid + risk;
  const target2 = entryMid + 2 * risk;
  const target3 = entryMid + 3 * risk;
  if (
    stopLoss <= 0
    || ticker.price <= stopLoss
    || ticker.price >= target1
    || !(stopLoss < entryLow && entryLow <= entryHigh && entryHigh < breakout)
    || !(breakout < target1 && target1 < target2 && target2 < target3)
  ) return null;

  const closes = closed.map((candle) => candle.close);
  const ema20 = ema(closes.slice(-60), 20);
  const ema50 = ema(closes.slice(-60), 50);
  const recentVolume = average(closed.slice(-5).map((candle) => candle.volume));
  const baselineVolume = average(closed.slice(-25, -5).map((candle) => candle.volume));
  const volumeRatio = baselineVolume > 0 ? recentVolume / baselineVolume : 0;
  const proximityAtr = Math.abs(breakout - last.close) / atr;
  let score = 50;
  if (ema20 > ema50) score += 12; else score -= 8;
  if (last.close > ema20) score += 6;
  if (volumeRatio >= 1.2) score += 8; else if (volumeRatio >= 0.9) score += 4;
  if (proximityAtr <= 1) score += 12; else if (proximityAtr <= 2) score += 8; else score += 3;
  if (freshBreakout) score += 8;
  if (ticker.quoteVolume >= 50_000_000) score += 6;
  else if (ticker.quoteVolume >= 10_000_000) score += 3;
  score = Math.max(0, Math.min(99, Math.round(score)));
  if (score < 65 || (ticker.quoteVolume < 10_000_000 && score < 80)) return null;

  const reasons = [
    freshBreakout
      ? "Fresh 4H close above 20-candle resistance"
      : `${(((breakout - last.close) / breakout) * 100).toFixed(1)}% below 20-candle resistance`,
    ema20 > ema50 ? "EMA20 above EMA50" : "Trend filter mixed",
    volumeRatio >= 1.2 ? `volume ${volumeRatio.toFixed(1)}× baseline` : "volume not extended",
    `$${Math.round(ticker.quoteVolume / 1_000_000)}M 24H liquidity`,
  ];

  return {
    symbol: ticker.symbol,
    strategy: "breakout",
    breakout,
    entryLow,
    entryHigh,
    stopLoss,
    target1,
    target2,
    target3,
    cancelBelow,
    score,
    reason: reasons.join(" • "),
    status: freshBreakout ? "armed" : "waiting",
    lastPrice: ticker.price,
    atr,
    volumeRatio,
  };
}
