import type { Candle, Ticker } from "./market";
import {
  average,
  ema,
  zoneTouched,
  type StrategyCandidate,
} from "./strategy";

function atr14(candles: Candle[]) {
  const ranges = candles.slice(-15).map((candle, index, recent) => {
    const priorClose = index === 0 ? candles.at(-16)!.close : recent[index - 1].close;
    return Math.max(
      candle.high - candle.low,
      Math.abs(candle.high - priorClose),
      Math.abs(candle.low - priorClose),
    );
  });
  return average(ranges);
}

/**
 * Daily trend uses only daily candles closed before `now`.
 * Rules: close above EMA50, EMA20 above EMA50, and EMA50 rising.
 */
export function isDailyUptrend(dailyCandles: Candle[], now: number) {
  const closed = dailyCandles
    .filter((candle) => candle.closeTime < now)
    .sort((a, b) => a.openTime - b.openTime);
  if (closed.length < 61) return false;
  const recent = closed.slice(-61);
  const current = recent.map((candle) => candle.close);
  const previous = recent.slice(0, -1).map((candle) => candle.close);
  const currentEma20 = ema(current, 20);
  const currentEma50 = ema(current, 50);
  const previousEma50 = ema(previous, 50);
  return recent.at(-1)!.close > currentEma50
    && currentEma20 > currentEma50
    && currentEma50 > previousEma50;
}

/**
 * A confirmed Daily/4H trend pullback. The 4H candle must touch the EMA20–EMA50
 * zone and close bullish above it. Entries are executed later by the backtest
 * at the next candle's open; this function never assumes a same-candle fill.
 */
export function analyseTrendPullback(
  ticker: Ticker,
  inputCandles: Candle[],
  dailyCandles: Candle[],
  now = Date.now(),
): StrategyCandidate | null {
  if (!isDailyUptrend(dailyCandles, now) || ticker.quoteVolume < 5_000_000) return null;
  const closed = inputCandles
    .filter((candle) => candle.closeTime < now)
    .sort((a, b) => a.openTime - b.openTime);
  if (closed.length < 60) return null;

  const last = closed.at(-1)!;
  const closes = closed.map((candle) => candle.close);
  const ema20 = ema(closes.slice(-60), 20);
  const ema50 = ema(closes.slice(-60), 50);
  const atr = atr14(closed);
  if (!(atr > 0) || ema20 <= ema50 || atr / last.close < 0.001) return null;

  const entryLow = ema50 - 0.15 * atr;
  const entryHigh = ema20 + 0.15 * atr;
  const levels = { entryLow, entryHigh };
  const confirmed = zoneTouched(last, levels)
    && last.close > last.open
    && last.close > entryHigh
    && last.close <= entryHigh + atr;
  if (!confirmed) return null;

  const stopLoss = Math.min(
    entryLow,
    ...closed.slice(-6).map((candle) => candle.low),
  ) - 0.2 * atr;
  const cancelBelow = Math.max(stopLoss, entryLow - 0.3 * atr);
  const referenceEntry = last.close;
  const risk = referenceEntry - stopLoss;
  const target1 = referenceEntry + risk;
  const target2 = referenceEntry + 2 * risk;
  const target3 = referenceEntry + 3 * risk;
  if (
    !(risk > 0)
    || stopLoss <= 0
    || cancelBelow < stopLoss
    || cancelBelow >= referenceEntry
    || target1 <= referenceEntry
  ) return null;

  const recentVolume = average(closed.slice(-5).map((candle) => candle.volume));
  const baselineVolume = average(closed.slice(-25, -5).map((candle) => candle.volume));
  const volumeRatio = baselineVolume > 0 ? recentVolume / baselineVolume : 0;
  let score = 60;
  if (volumeRatio >= 1.2) score += 10;
  else if (volumeRatio >= 0.9) score += 4;
  if (ticker.quoteVolume >= 50_000_000) score += 6;
  else if (ticker.quoteVolume >= 10_000_000) score += 3;
  if (last.close > ema20) score += 5;
  score += last.close <= entryHigh + 0.5 * atr ? 8 : 3;
  score = Math.max(0, Math.min(99, Math.round(score)));
  if (score < 65 || (ticker.quoteVolume < 10_000_000 && score < 80)) return null;

  return {
    symbol: ticker.symbol,
    strategy: "trend_pullback",
    breakout: entryHigh,
    entryLow,
    entryHigh,
    stopLoss,
    target1,
    target2,
    target3,
    cancelBelow,
    score,
    reason: [
      "Daily EMA20 above rising EMA50",
      "Bullish 4H pullback confirmed above EMA zone",
      volumeRatio >= 1.2 ? `volume ${volumeRatio.toFixed(1)}× baseline` : "volume not extended",
      `$${Math.round(ticker.quoteVolume / 1_000_000)}M 24H liquidity`,
    ].join(" • "),
    status: "armed",
    lastPrice: last.close,
    atr,
    volumeRatio,
  };
}
