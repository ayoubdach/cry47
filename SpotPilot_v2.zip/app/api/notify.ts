import { log } from "./lib/logger";
import { sendTelegram } from "./telegram";

/** Sends a Telegram alert without ever breaking the caller, but records failures instead of hiding them. */
export async function notifyTelegram(text: string) {
  try {
    const result = await sendTelegram(text);
    if (!result.delivered && result.reason !== "not_configured") {
      log.warn("telegram alert not delivered", { reason: result.reason });
    }
  } catch (error) {
    log.warn("telegram alert failed", { error: error instanceof Error ? error.message : String(error) });
  }
}
