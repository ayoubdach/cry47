import { beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  listSetups: vi.fn(),
  createSetup: vi.fn(),
  cancelSetup: vi.fn(),
  addAlert: vi.fn(),
  getCandles: vi.fn(),
  getTickers: vi.fn(),
  analyseMarket: vi.fn(),
  isDailyUptrend: vi.fn(),
  sendTelegram: vi.fn(),
}));

vi.mock("./queries/setups", () => ({
  listSetups: mocks.listSetups,
  createSetup: mocks.createSetup,
  cancelSetup: mocks.cancelSetup,
  addAlert: mocks.addAlert,
}));
vi.mock("./market", () => ({ getCandles: mocks.getCandles, getTickers: mocks.getTickers }));
vi.mock("./strategy", async (importOriginal) => ({
  ...await importOriginal<typeof import("./strategy")>(),
  analyseMarket: mocks.analyseMarket,
}));
vi.mock("./trend-strategy", () => ({ isDailyUptrend: mocks.isDailyUptrend }));
vi.mock("./telegram", () => ({ sendTelegram: mocks.sendTelegram }));

import { runRadar } from "./radar";

function candidate(score: number) {
  return {
    symbol: "TESTUSDT",
    strategy: "breakout",
    breakout: 110,
    entryLow: 99,
    entryHigh: 101,
    stopLoss: 90,
    target1: 120,
    target2: 130,
    target3: 140,
    cancelBelow: 95,
    score,
    reason: "test structure",
    status: "waiting",
    lastPrice: 105,
    atr: 2,
    volumeRatio: 1.2,
  };
}

beforeEach(() => {
  vi.clearAllMocks();
  mocks.listSetups.mockResolvedValue([]);
  mocks.getTickers.mockResolvedValue({ data: [{ symbol: "TESTUSDT", quoteVolume: 20_000_000 }] });
  mocks.getCandles.mockResolvedValue([]);
  mocks.isDailyUptrend.mockReturnValue(true);
  mocks.addAlert.mockResolvedValue(undefined);
  mocks.sendTelegram.mockResolvedValue({ delivered: false });
  mocks.createSetup.mockImplementation((data) => Promise.resolve({
    ...data,
    id: mocks.createSetup.mock.calls.length,
    createdAt: new Date(),
    updatedAt: new Date(),
  }));
});

describe("dual forward radar", () => {
  it("creates distinct baseline and Elite paper setups from the same 85+ structure", async () => {
    mocks.analyseMarket.mockReturnValue(candidate(90));

    const result = await runRadar();

    expect(result.added).toBe(2);
    expect(result.eliteAdded).toBe(1);
    expect(mocks.createSetup.mock.calls.map(([data]) => data.strategy)).toEqual(["breakout_daily_elite", "breakout"]);
    expect(mocks.getCandles).toHaveBeenCalledWith("TESTUSDT", "1d", 80);
    expect(mocks.addAlert.mock.calls.some(([data]) => data.title.includes("ELITE BREAKOUT"))).toBe(true);
    // Radar discoveries stay on the dashboard; Telegram only gets entries, targets and stops.
    expect(mocks.sendTelegram).not.toHaveBeenCalled();
  });

  it("does not promote a sub-85 candidate or fetch Daily candles for it", async () => {
    mocks.analyseMarket.mockReturnValue(candidate(84));

    const result = await runRadar();

    expect(result.added).toBe(1);
    expect(result.eliteAdded).toBe(0);
    expect(mocks.createSetup.mock.calls[0][0].strategy).toBe("breakout");
    expect(mocks.getCandles).toHaveBeenCalledTimes(1);
  });
});
