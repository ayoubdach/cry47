import { describe, expect, it } from "vitest";
import { simulateMarket, summariseBacktest } from "./backtest-engine";
import { analyseMarket, historicalTicker, type EntryMode } from "./strategy";
import { candle, dailyCandlesEnding, FOUR_HOURS, marketCandles } from "./test-fixtures";
import { analyseTrendPullback } from "./trend-strategy";

const COSTS = { feeBps: 10, slippageBps: 5 };

function sequence(mode: EntryMode, resolution: "targets" | "stop-and-targets") {
  const candles = marketCandles(true);
  const candidate = analyseMarket(
    { ...historicalTicker(candles), symbol: "TESTUSDT" },
    candles,
    61 * FOUR_HOURS,
  );
  expect(candidate).not.toBeNull();
  if (!candidate) throw new Error("Missing fixture candidate");
  const atr = candidate.atr;
  const retestOpen = candidate.entryHigh + 0.2 * atr;
  const retestClose = candidate.entryHigh + 0.4 * atr;
  candles.push(candle(
    61,
    retestOpen,
    retestOpen + 0.2 * atr,
    candidate.entryLow + 0.2 * atr,
    retestClose,
  ));
  candles.push(candle(
    62,
    retestClose,
    candidate.target3 + atr,
    resolution === "targets" ? retestClose - 0.2 * atr : candidate.stopLoss - atr,
    resolution === "targets" ? candidate.target3 + 0.2 * atr : retestClose,
  ));
  return { candles, candidate, result: simulateMarket("TESTUSDT", candles, mode, COSTS) };
}

function pullbackSequence() {
  const candles = marketCandles();
  candles.push(candle(60, 104.6, 105.8, 104.2, 105.4));
  const dailyCandles = dailyCandlesEnding(61 * FOUR_HOURS);
  const candidate = analyseTrendPullback(
    { ...historicalTicker(candles), symbol: "TESTUSDT" },
    candles,
    dailyCandles,
    61 * FOUR_HOURS,
  );
  expect(candidate).not.toBeNull();
  if (!candidate) throw new Error("Missing pullback fixture candidate");
  const nextOpen = candidate.breakout + 0.2 * candidate.atr;
  candles.push(candle(61, nextOpen, nextOpen + 0.2 * candidate.atr, nextOpen - 0.2 * candidate.atr, nextOpen + 0.1 * candidate.atr));
  candles.push(candle(62, nextOpen, nextOpen + 12 * candidate.atr, nextOpen - 0.2 * candidate.atr, nextOpen + 2 * candidate.atr));
  const result = simulateMarket("TESTUSDT", candles, "confirmed", COSTS, {
    strategy: "trend_pullback",
    dailyCandles,
  });
  return { candles, candidate, result, nextOpen };
}

describe("historical execution engine", () => {
  it("enters only after breakout and a later retest, then records all three targets", () => {
    const touch = sequence("touch", "targets");
    const confirmed = sequence("confirmed", "targets");

    for (const fixture of [touch, confirmed]) {
      expect(fixture.result.trades).toHaveLength(1);
      expect(fixture.result.trades[0].entryTime).toBe(fixture.candles[61].closeTime);
      expect(fixture.result.trades[0].entryTime).toBeGreaterThan(fixture.candles[60].closeTime);
      expect(fixture.result.trades[0].outcome).toBe("completed");
      expect(fixture.result.trades[0].targetsHit).toBe(3);
      expect(fixture.result.trades[0].rMultiple).toBeGreaterThan(0);
    }
    expect(confirmed.result.trades[0].entryPrice).toBeGreaterThan(touch.result.trades[0].entryPrice);
  });

  it("uses stop-first accounting when stop and targets share one ambiguous candle", () => {
    for (const mode of ["touch", "confirmed"] as const) {
      const { result } = sequence(mode, "stop-and-targets");
      expect(result.trades).toHaveLength(1);
      expect(result.trades[0].outcome).toBe("stopped");
      expect(result.trades[0].targetsHit).toBe(0);
      expect(result.trades[0].rMultiple).toBeLessThan(0);
    }
  });

  it("charges fees and slippage instead of presenting friction-free returns", () => {
    const fixture = sequence("confirmed", "targets");
    const withoutCosts = simulateMarket("TESTUSDT", fixture.candles, "confirmed", { feeBps: 0, slippageBps: 0 });
    expect(fixture.result.trades[0].rMultiple).toBeLessThan(withoutCosts.trades[0].rMultiple);
  });

  it("calculates expectancy and drawdown from closed trades", () => {
    const win = sequence("touch", "targets").result;
    const loss = sequence("touch", "stop-and-targets").result;
    const metrics = summariseBacktest([win, loss]);

    expect(metrics.tradesCount).toBe(2);
    expect(metrics.wins).toBe(1);
    expect(metrics.losses).toBe(1);
    expect(metrics.winRate).toBe(50);
    expect(metrics.maxDrawdownR).toBeGreaterThan(0);
    expect(metrics.expectancyR).toBeCloseTo(metrics.netR / 2);
  });

  it("enters a confirmed pullback at the next open, never the confirmation close", () => {
    const fixture = pullbackSequence();
    expect(fixture.result.trades).toHaveLength(1);
    const trade = fixture.result.trades[0];
    expect(trade.strategy).toBe("trend_pullback");
    expect(trade.entryTime).toBe(fixture.candles[61].openTime);
    expect(trade.entryTime).toBeGreaterThan(fixture.candles[60].closeTime);
    expect(trade.entryPrice).toBeCloseTo(fixture.nextOpen * 1.0005);
    expect(trade.outcome).toBe("completed");
  });

  it("uses fixed 4%, 7%, and 8% targets from the actual small-target entry", () => {
    const fixture = pullbackSequence();
    const result = simulateMarket("TESTUSDT", fixture.candles, "confirmed", COSTS, {
      strategy: "pullback_small",
      dailyCandles: dailyCandlesEnding(61 * FOUR_HOURS),
    });

    expect(result.trades).toHaveLength(1);
    const trade = result.trades[0];
    expect(trade.strategy).toBe("pullback_small");
    expect(trade.target1).toBeCloseTo(fixture.nextOpen * 1.04);
    expect(trade.target2).toBeCloseTo(fixture.nextOpen * 1.07);
    expect(trade.target3).toBeCloseTo(fixture.nextOpen * 1.08);
    expect(trade.outcome).toBe("completed");
    expect(trade.targetsHit).toBe(3);
  });

  it("closes stagnant small-target trades at the five-day time exit", () => {
    const fixture = pullbackSequence();
    const candles = fixture.candles.slice(0, 62);
    for (let index = 62; index <= 91; index += 1) {
      candles.push(candle(
        index,
        fixture.nextOpen,
        fixture.nextOpen + 0.1 * fixture.candidate.atr,
        fixture.nextOpen - 0.1 * fixture.candidate.atr,
        fixture.nextOpen,
      ));
    }
    const result = simulateMarket("TESTUSDT", candles, "confirmed", COSTS, {
      strategy: "pullback_small",
      dailyCandles: dailyCandlesEnding(61 * FOUR_HOURS),
    });

    expect(result.trades).toHaveLength(1);
    expect(result.trades[0].outcome).toBe("timed_out");
    expect(result.trades[0].targetsHit).toBe(0);
    expect(result.trades[0].exitTime).toBe(candles[91].closeTime);
    expect(result.trades[0].returnPercent).toBeLessThan(0);
    expect(result.openCount).toBe(0);
  });

  it("applies the Daily filter to breakout entries without changing the baseline", () => {
    const candles = sequence("touch", "targets").candles;
    const end = candles.at(-1)!.closeTime + 1;
    const baseline = simulateMarket("TESTUSDT", candles, "touch", COSTS);
    const filtered = simulateMarket("TESTUSDT", candles, "touch", COSTS, {
      strategy: "breakout_daily",
      dailyCandles: dailyCandlesEnding(end),
    });
    const rejected = simulateMarket("TESTUSDT", candles, "touch", COSTS, {
      strategy: "breakout_daily",
      dailyCandles: dailyCandlesEnding(end, 70, false),
    });
    const elite = simulateMarket("TESTUSDT", candles, "touch", COSTS, {
      strategy: "breakout_daily_elite",
      dailyCandles: dailyCandlesEnding(end),
    });
    expect(baseline.trades).toHaveLength(1);
    expect(filtered.trades).toHaveLength(1);
    expect(filtered.trades[0].strategy).toBe("breakout_daily");
    expect(rejected.trades).toHaveLength(0);
    expect(elite.trades).toHaveLength(1);
    expect(elite.trades[0].strategy).toBe("breakout_daily_elite");
  });
});
