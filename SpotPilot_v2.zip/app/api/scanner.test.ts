import { beforeEach, describe, expect, it, vi } from "vitest";
import type { Setup } from "@db/schema";
import type { Candle } from "./market";

const mocks = vi.hoisted(() => ({
  listSetups: vi.fn(),
  updateSetup: vi.fn(),
  addAlert: vi.fn(),
  getCandles: vi.fn(),
  getTickers: vi.fn(),
  sendTelegram: vi.fn(),
}));

vi.mock("./queries/setups", () => ({
  listSetups: mocks.listSetups,
  updateSetup: mocks.updateSetup,
  addAlert: mocks.addAlert,
}));
vi.mock("./market", () => ({ getCandles: mocks.getCandles, getTickers: mocks.getTickers }));
vi.mock("./telegram", () => ({ sendTelegram: mocks.sendTelegram }));

import { runScan } from "./scanner";

function setup(strategy = "breakout_daily_elite"): Setup {
  const now = new Date();
  return {
    id: 1,
    symbol: "TESTUSDT",
    breakout: "110",
    entryLow: "99",
    entryHigh: "101",
    stopLoss: "90",
    target1: "120",
    target2: "130",
    target3: "140",
    cancelBelow: "95",
    riskPercent: "0.50",
    source: "radar",
    strategy,
    entryMode: "touch",
    score: 90,
    reason: "test",
    status: "armed",
    lastPrice: "105",
    armedAt: new Date(Date.now() - 5 * 60 * 60 * 1000),
    createdAt: now,
    updatedAt: now,
  };
}

function candles(rising: boolean): Candle[] {
  return Array.from({ length: 80 }, (_, index) => {
    const close = rising ? 50 + index : 200 - index;
    const openTime = Date.now() - (81 - index) * 24 * 60 * 60 * 1000;
    return {
      openTime,
      closeTime: openTime + 23 * 60 * 60 * 1000,
      open: close - 0.2,
      high: close + 0.5,
      low: close - 0.5,
      close,
      volume: 1000,
      quoteVolume: 100_000,
    };
  });
}

const fourHour: Candle = {
  openTime: Date.now() - 5 * 60 * 60 * 1000,
  closeTime: Date.now() - 60 * 60 * 1000,
  open: 104,
  high: 106,
  low: 103,
  close: 105,
  volume: 1000,
  quoteVolume: 100_000,
};

beforeEach(() => {
  vi.clearAllMocks();
  mocks.updateSetup.mockResolvedValue(undefined);
  mocks.addAlert.mockResolvedValue(undefined);
  mocks.sendTelegram.mockResolvedValue({ delivered: false });
  mocks.getTickers.mockResolvedValue({ data: [{ symbol: "TESTUSDT", price: 100 }] });
});

describe("forward paper scanner", () => {
  it("activates an Elite retest only when the Daily trend passes the entry recheck", async () => {
    mocks.listSetups.mockResolvedValue([setup()]);
    mocks.getCandles.mockImplementation((_symbol, interval) => Promise.resolve(interval === "1d" ? candles(true) : [fourHour]));

    const result = await runScan();

    expect(result.transitions).toBe(1);
    expect(mocks.updateSetup).toHaveBeenCalledWith(1, expect.objectContaining({ status: "active" }));
    expect(mocks.addAlert.mock.calls[0][0].message).toContain("Daily uptrend rechecked at entry");
    const telegram = mocks.sendTelegram.mock.calls[0][0];
    expect(telegram).toContain("ENTRY · TEST/USDT");
    expect(telegram).toContain("Elite");
    expect(telegram).toContain("Stop   90");
    expect(telegram).toContain("TP1    120");
    expect(telegram).toContain("TP2    130");
    expect(telegram).toContain("TP3    140");
  });

  it("cancels before entry when the Elite Daily filter fails", async () => {
    mocks.listSetups.mockResolvedValue([setup()]);
    mocks.getCandles.mockImplementation((_symbol, interval) => Promise.resolve(interval === "1d" ? candles(false) : [fourHour]));

    await runScan();

    expect(mocks.updateSetup).toHaveBeenCalledWith(1, expect.objectContaining({ status: "cancelled" }));
    expect(mocks.updateSetup).not.toHaveBeenCalledWith(1, expect.objectContaining({ status: "active" }));
    expect(mocks.addAlert.mock.calls[0][0].message).toContain("no paper position opened");
    // A setup that never entered must not buzz the phone.
    expect(mocks.sendTelegram).not.toHaveBeenCalled();
  });

  it("sends a dedicated TP1 alert with the complete target ladder", async () => {
    mocks.listSetups.mockResolvedValue([{ ...setup(), status: "active" as const }]);
    mocks.getTickers.mockResolvedValue({ data: [{ symbol: "TESTUSDT", price: 121 }] });
    mocks.getCandles.mockResolvedValue([fourHour]);

    await runScan();

    expect(mocks.updateSetup).toHaveBeenCalledWith(1, expect.objectContaining({ status: "tp1" }));
    const telegram = mocks.sendTelegram.mock.calls[0][0];
    expect(telegram).toContain("TARGET 1 HIT");
    expect(telegram).toContain("TP1 120 reached");
    expect(telegram).toContain("TP1 ✅   TP2 ⬜   TP3 ⬜");
    expect(telegram).toContain("Next: TP2 130");
  });

  it("catches a stop wick that happened between polls even if the last price recovered", async () => {
    const lastCheck = new Date(Date.now() - 90_000);
    mocks.listSetups.mockResolvedValue([{ ...setup(), status: "active" as const, updatedAt: lastCheck }]);
    mocks.getTickers.mockResolvedValue({ data: [{ symbol: "TESTUSDT", price: 100 }] });
    const wick: Candle = { ...fourHour, openTime: Date.now() - 60_000, closeTime: Date.now() - 1_000, low: 89, high: 101 };
    mocks.getCandles.mockImplementation((_symbol, interval) => Promise.resolve(interval === "1m" ? [wick] : [fourHour]));

    await runScan();

    expect(mocks.updateSetup).toHaveBeenCalledWith(1, expect.objectContaining({ status: "stopped" }));
  });

  it("keeps the baseline entry path independent of the Elite Daily gate", async () => {
    mocks.listSetups.mockResolvedValue([setup("breakout")]);
    mocks.getCandles.mockResolvedValue([fourHour]);

    await runScan();

    expect(mocks.updateSetup).toHaveBeenCalledWith(1, expect.objectContaining({ status: "active" }));
    expect(mocks.getCandles).toHaveBeenCalledTimes(1);
    expect(mocks.getCandles).toHaveBeenCalledWith("TESTUSDT", "4h", 12);
  });
});
