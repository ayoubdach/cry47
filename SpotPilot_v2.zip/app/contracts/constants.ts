export const SUPPORTED_SYMBOLS = [
  "BTCUSDT",
  "ETHUSDT",
  "SOLUSDT",
  "UNIUSDT",
  "NEARUSDT",
  "LINKUSDT",
] as const;

export type SupportedSymbol = (typeof SUPPORTED_SYMBOLS)[number];

export const SETUP_STATUSES = [
  "waiting",
  "armed",
  "active",
  "tp1",
  "tp2",
  "completed",
  "stopped",
  "cancelled",
] as const;

export type SetupStatus = (typeof SETUP_STATUSES)[number];

export const ACTIVE_STATUSES: SetupStatus[] = ["active", "tp1", "tp2"];
export const OPEN_STATUSES: SetupStatus[] = ["waiting", "armed", "active", "tp1", "tp2"];
