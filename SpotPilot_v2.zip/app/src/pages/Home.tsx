import { useMemo, useState } from "react";
import {
  Activity,
  AlertTriangle,
  Bell,
  CheckCircle2,
  ChevronRight,
  Circle,
  Clock3,
  FlaskConical,
  Plus,
  Radar,
  RefreshCw,
  Send,
  ShieldCheck,
  XCircle,
} from "lucide-react";
import { MarketChart } from "@/components/MarketChart";
import { BacktestLab } from "@/components/BacktestLab";
import { NewSetupDialog } from "@/components/NewSetupDialog";
import { TelegramDialog } from "@/components/TelegramDialog";
import { SUPPORTED_SYMBOLS } from "@contracts/constants";
import { trpc } from "@/providers/trpc";

const statusMeta: Record<string, { label: string; className: string }> = {
  waiting: { label: "WAITING 4H", className: "status-waiting" },
  armed: { label: "RETEST ARMED", className: "status-armed" },
  active: { label: "ENTRY ACTIVE", className: "status-active" },
  tp1: { label: "TP1 HIT", className: "status-active" },
  tp2: { label: "TP2 HIT", className: "status-active" },
  completed: { label: "COMPLETED", className: "status-complete" },
  stopped: { label: "STOPPED", className: "status-stopped" },
  cancelled: { label: "CANCELLED", className: "status-cancelled" },
};

function pair(symbol: string) {
  return symbol.replace("USDT", "/USDT");
}

function price(value: number | string | null | undefined) {
  const number = Number(value ?? 0);
  if (!Number.isFinite(number)) return "—";
  const digits = Math.abs(number) >= 1000 ? 0 : Math.abs(number) >= 100 ? 2 : Math.abs(number) >= 1 ? 3 : 5;
  return number.toLocaleString("en-US", { minimumFractionDigits: digits, maximumFractionDigits: digits });
}

function time(value: Date | string) {
  return new Intl.DateTimeFormat("en", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" }).format(new Date(value));
}

function AlertIcon({ kind }: { kind: string }) {
  if (["target", "completed"].includes(kind)) return <CheckCircle2 size={15} />;
  if (["stopped", "cancelled"].includes(kind)) return <XCircle size={15} />;
  if (kind === "entry") return <Activity size={15} />;
  if (["breakout", "discovered"].includes(kind)) return <Radar size={15} />;
  return <Clock3 size={15} />;
}

export default function Home() {
  const utils = trpc.useUtils();
  const tickersQuery = trpc.market.tickers.useQuery(undefined, { refetchInterval: 30_000, retry: 1 });
  const setupsQuery = trpc.setups.list.useQuery(undefined, { refetchInterval: 45_000 });
  const alertsQuery = trpc.alerts.list.useQuery(undefined, { refetchInterval: 45_000 });
  const telegramQuery = trpc.telegram.status.useQuery();
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [selectedSymbol, setSelectedSymbol] = useState("UNIUSDT");
  const [filter, setFilter] = useState("all");
  const [workspace, setWorkspace] = useState<"radar" | "lab">("radar");
  const [newOpen, setNewOpen] = useState(false);
  const [telegramOpen, setTelegramOpen] = useState(false);
  const [scanNote, setScanNote] = useState("");

  const setups = setupsQuery.data ?? [];
  const tickers = tickersQuery.data?.data ?? [];
  const preferredSetup = (nextSymbol: string) =>
    setups.find((s) => s.symbol === nextSymbol && !["completed", "stopped", "cancelled"].includes(s.status))
    ?? setups.find((s) => s.symbol === nextSymbol);
  const topRadar = setups
    .filter((setup) => setup.source === "radar" && !["completed", "stopped", "cancelled"].includes(setup.status))
    .sort((a, b) => Number(b.strategy === "breakout_daily_elite") - Number(a.strategy === "breakout_daily_elite") || b.score - a.score)[0];
  const selected = selectedId === null
    ? topRadar ?? preferredSetup(selectedSymbol) ?? setups.find((s) => !["completed", "stopped", "cancelled"].includes(s.status)) ?? setups[0]
    : setups.find((s) => s.id === selectedId);
  const symbol = selected?.symbol ?? selectedSymbol;
  const trackedSymbols = setups.filter((setup) => !["completed", "stopped", "cancelled"].includes(setup.status)).map((setup) => setup.symbol);
  const watchSymbols = Array.from(new Set([...SUPPORTED_SYMBOLS, ...trackedSymbols, ...tickers.slice(0, 8).map((item) => item.symbol)]));
  const tickerItems = Array.from(new Set([symbol, ...trackedSymbols, ...tickers.slice(0, 12).map((item) => item.symbol)]))
    .map((item) => tickers.find((ticker) => ticker.symbol === item))
    .filter((item): item is (typeof tickers)[number] => Boolean(item));
  const ticker = tickers.find((item) => item.symbol === symbol);
  const candlesQuery = trpc.market.candles.useQuery(
    { symbol, interval: "4h", limit: 50 },
    { refetchInterval: 60_000, retry: 1 },
  );

  const refreshQueries = () => {
    utils.setups.list.invalidate();
    utils.alerts.list.invalidate();
    utils.market.tickers.invalidate();
  };
  const scan = trpc.scan.run.useMutation({
    onSuccess: (result) => {
      setScanNote(`${result.transitions} transitions • ${result.errors} feed errors`);
      refreshQueries();
    },
    onError: (error) => setScanNote(error.message),
  });
  const radar = trpc.radar.run.useMutation({
    onSuccess: (result) => {
      setScanNote(`Radar: ${result.scanned} markets • ${result.candidates} qualified • ${result.added} added (${result.eliteAdded} Elite)`);
      const first = result.opportunities[0];
      if (first) {
        setSelectedId(first.id);
        setSelectedSymbol(first.symbol);
      }
      refreshQueries();
    },
    onError: (error) => setScanNote(error.message),
  });
  const cancel = trpc.setups.cancel.useMutation({ onSuccess: refreshQueries });

  const filtered = useMemo(() => {
    const result = setups.filter((setup) => {
      if (filter === "radar") return setup.source === "radar" && !["completed", "stopped", "cancelled"].includes(setup.status);
      if (filter === "elite") return setup.strategy === "breakout_daily_elite";
      if (filter === "open") return ["waiting", "armed"].includes(setup.status);
      if (filter === "active") return ["active", "tp1", "tp2"].includes(setup.status);
      if (filter === "closed") return ["completed", "stopped", "cancelled"].includes(setup.status);
      return true;
    });
    return filter === "radar" ? result.sort((a, b) => b.score - a.score) : result;
  }, [setups, filter]);

  function chooseSymbol(next: string) {
    setWorkspace("radar");
    setSelectedSymbol(next);
    const match = preferredSetup(next);
    setSelectedId(match?.id ?? -1);
  }

  const openCount = setups.filter((s) => ["waiting", "armed"].includes(s.status)).length;
  const activeCount = setups.filter((s) => ["active", "tp1", "tp2"].includes(s.status)).length;
  const stoppedCount = setups.filter((s) => s.status === "stopped").length;
  const radarCount = setups.filter((s) => s.source === "radar" && !["completed", "stopped", "cancelled"].includes(s.status)).length;
  const eliteCount = setups.filter((s) => s.strategy === "breakout_daily_elite" && !["completed", "stopped", "cancelled"].includes(s.status)).length;
  const selectedIsElite = selected?.strategy === "breakout_daily_elite";
  const stage = !selected || ["waiting", "cancelled"].includes(selected.status) ? 0 : selected.status === "armed" ? 1 : ["active", "tp1", "tp2"].includes(selected.status) ? 2 : 3;
  const entryMid = selected ? (Number(selected.entryLow) + Number(selected.entryHigh)) / 2 : 0;
  const rr = selected ? (Number(selected.target2) - entryMid) / Math.max(entryMid - Number(selected.stopLoss), Number.EPSILON) : 0;

  return (
    <div className="min-h-dvh bg-[#050810] text-slate-100">
      <header className="app-header">
        <div className="flex min-w-0 items-center gap-3">
          <div className="brand-mark" aria-hidden="true"><Radar size={21} /></div>
          <div className="min-w-0">
            <div className="flex items-baseline gap-2">
              <span className="brand-name truncate font-mono text-[15px] font-semibold tracking-[0.16em]">SPOTPILOT</span>
              <span className="hidden font-mono text-[10px] tracking-[0.14em] text-slate-500 sm:inline">PAPER DESK</span>
            </div>
            <p className="hidden text-xs text-slate-500 sm:block">Breakout → retest → disciplined entry</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div className="mr-1 hidden items-center gap-2 md:flex" title="Public Binance spot feed">
            <span className={`status-dot ${tickersQuery.isError ? "bg-red-400" : "bg-emerald-400"}`} />
            <span className="font-mono text-[10px] tracking-wider text-slate-400">{tickersQuery.data?.stale ? "CACHED FEED" : "SPOT FEED"}</span>
          </div>
          <button className="button-secondary compact" aria-label={workspace === "lab" ? "Return to opportunity radar" : "Open strategy lab"} title="Compare and validate entry strategies" onClick={() => setWorkspace(workspace === "lab" ? "radar" : "lab")}>
            <FlaskConical size={15} />
            <span className="hidden lg:inline">{workspace === "lab" ? "Radar" : "Strategy Lab"}</span>
          </button>
          <button className="button-secondary compact" aria-label="Find opportunities" title="Scan up to 120 liquid markets" onClick={() => { setWorkspace("radar"); setScanNote(""); radar.mutate(); }} disabled={radar.isPending}>
            <Radar size={15} className={radar.isPending ? "animate-spin" : ""} />
            <span className="hidden lg:inline">{radar.isPending ? "Scanning…" : "Find opportunities"}</span>
          </button>
          <button className="button-secondary compact" aria-label="Run entry scan" onClick={() => { setScanNote(""); scan.mutate(); }} disabled={scan.isPending}>
            <RefreshCw size={15} className={scan.isPending ? "animate-spin" : ""} />
            <span className="hidden sm:inline">{scan.isPending ? "Scanning…" : "Run scan"}</span>
          </button>
          <button className="button-primary compact" onClick={() => setNewOpen(true)}>
            <Plus size={16} /><span className="hidden sm:inline">New setup</span><span className="sm:hidden">Setup</span>
          </button>
        </div>
      </header>

      <div className="ticker-strip" aria-label="Live spot market ticker">
        {tickersQuery.isLoading && <span className="px-4 py-3 font-mono text-xs text-slate-500">CONNECTING TO PUBLIC SPOT FEED…</span>}
        {tickersQuery.isError && <span className="px-4 py-3 text-sm text-amber-300">Market feed unavailable. Retry with Run scan.</span>}
        {tickerItems.map((item) => (
          <button key={item.symbol} className={`ticker-item ${item.symbol === symbol ? "ticker-selected" : ""}`} onClick={() => chooseSymbol(item.symbol)}>
            <span className="font-mono text-[11px] text-slate-400">{item.symbol.replace("USDT", "")}</span>
            <span className="font-mono text-xs font-medium">{price(item.price)}</span>
            <span className={`font-mono text-[11px] ${item.changePercent >= 0 ? "text-emerald-300" : "text-red-300"}`}>
              {item.changePercent >= 0 ? "+" : ""}{item.changePercent.toFixed(2)}%
            </span>
          </button>
        ))}
      </div>

      <main className="dashboard-grid">
        <aside className="watch-panel" aria-label="Market watchlist">
          <div className="panel-heading">
            <div>
              <p className="section-label">WATCHLIST</p>
              <p className="section-subtitle">Binance spot • 24H</p>
            </div>
            <Activity size={15} className="text-cyan-300" />
          </div>
          <div className="watch-list">
            {watchSymbols.map((item) => {
              const data = tickers.find((t) => t.symbol === item);
              const setupCount = setups.filter((s) => s.symbol === item && !["completed", "stopped", "cancelled"].includes(s.status)).length;
              return (
                <button key={item} onClick={() => chooseSymbol(item)} className={`watch-row ${item === symbol ? "watch-row-selected" : ""}`}>
                  <div className="flex min-w-0 items-center gap-2">
                    <span className={`h-1.5 w-1.5 rounded-full ${setupCount ? "bg-cyan-300" : "bg-slate-700"}`} />
                    <span className="truncate font-mono text-xs font-medium">{pair(item)}</span>
                  </div>
                  <div className="text-right">
                    <p className="font-mono text-xs">{data ? price(data.price) : "—"}</p>
                    <p className={`font-mono text-[10px] ${(data?.changePercent ?? 0) >= 0 ? "text-emerald-300" : "text-red-300"}`}>
                      {data ? `${data.changePercent >= 0 ? "+" : ""}${data.changePercent.toFixed(2)}%` : "waiting"}
                    </p>
                  </div>
                </button>
              );
            })}
          </div>
          <div className="watch-stats">
            <div><span>Watching</span><strong>{openCount}</strong></div>
            <div><span>Active</span><strong>{activeCount}</strong></div>
            <div><span>Radar</span><strong className="text-cyan-300">{radarCount}</strong></div>
            <div><span>Elite forward</span><strong className="elite-text">{eliteCount}</strong></div>
            <div><span>Losses logged</span><strong className="text-red-300">{stoppedCount}</strong></div>
          </div>
          <div className="mx-4 mb-4 border-t border-[#1a2540] pt-4">
            <div className="flex items-start gap-2 text-xs leading-5 text-slate-400">
              <ShieldCheck size={16} className="mt-0.5 shrink-0 text-emerald-300" />
              <p>Paper only. No exchange keys, auto-trading, or profit promises.</p>
            </div>
          </div>
        </aside>

        <section className="detail-panel" aria-label={workspace === "lab" ? "Strategy validation lab" : "Selected paper setup"}>
          {workspace === "lab" ? <BacktestLab /> : (
            <>
          <div className="detail-topline">
            <div>
              <div className="flex flex-wrap items-center gap-3">
                <h1 className="font-mono text-xl font-semibold tracking-tight sm:text-2xl">{pair(symbol)}</h1>
                {selected && <span className={`setup-status ${statusMeta[selected.status]?.className}`}>{statusMeta[selected.status]?.label}</span>}
                {selected?.source === "radar" && <span className={selectedIsElite ? "elite-badge" : "radar-score"}>{selectedIsElite ? "ELITE FORWARD" : "RADAR"} {selected.score}/99</span>}
                {selected && <span className="entry-mode-badge">{selected.entryMode === "confirmed" ? "4H CONFIRMED ENTRY" : "ZONE TOUCH ENTRY"}</span>}
              </div>
              <p className="mt-1 text-sm text-slate-500">{selectedIsElite ? "Daily uptrend • 4H breakout–retest • score ≥85 • " : "4H breakout–retest • "}spot paper setup</p>
            </div>
            <div className="shrink-0 text-right">
              <p className="font-mono text-xl font-medium sm:text-2xl">{ticker ? `$${price(ticker.price)}` : "—"}</p>
              {ticker && <p className={`whitespace-nowrap font-mono text-xs ${ticker.changePercent >= 0 ? "text-emerald-300" : "text-red-300"}`}>{ticker.changePercent >= 0 ? "+" : ""}{ticker.changePercent.toFixed(2)}% / 24H</p>}
            </div>
          </div>

          {selected?.source === "radar" && selected.reason && (
            <div className={`radar-thesis ${selectedIsElite ? "elite-thesis" : ""}`}>
              <Radar size={15} />
              <div><span>{selectedIsElite ? "ELITE FORWARD PAPER • DAILY RECHECK AT ENTRY" : "WHY IT QUALIFIED"}</span><p>{selected.reason}</p></div>
            </div>
          )}

          <div className="chart-shell">
            <div className="mb-2 flex items-center justify-between px-1">
              <span className="section-label">PRICE STRUCTURE / 4H</span>
              <span className="font-mono text-[10px] text-slate-500">50 CANDLES</span>
            </div>
            {candlesQuery.isLoading ? (
              <div className="flex h-[250px] items-center justify-center font-mono text-xs text-slate-500">LOADING MARKET STRUCTURE…</div>
            ) : candlesQuery.isError ? (
              <div className="flex h-[250px] flex-col items-center justify-center gap-3 text-sm text-slate-400">
                <AlertTriangle size={20} className="text-amber-300" /> Chart feed unavailable
                <button className="text-cyan-300 underline underline-offset-4" onClick={() => candlesQuery.refetch()}>Retry chart</button>
              </div>
            ) : (
              <MarketChart candles={candlesQuery.data ?? []} symbol={symbol} levels={selected ?? undefined} />
            )}
          </div>

          {selected ? (
            <>
              <div className="stage-track" aria-label={`Setup stage ${stage + 1} of 4`}>
                {[selectedIsElite ? "Daily + 4H breakout" : "4H breakout", selected.entryMode === "confirmed" ? "Retest + 4H confirm" : "Retest zone", selectedIsElite ? "Daily recheck + entry" : "Paper entry", "Resolve"].map((label, index) => (
                  <div key={label} className={`stage-item ${index < stage ? "stage-done" : index === stage ? "stage-current" : ""}`}>
                    <span className="stage-node">{index < stage ? <CheckCircle2 size={14} /> : <Circle size={12} />}</span>
                    <span>{label}</span>
                  </div>
                ))}
              </div>

              <div className="levels-grid">
                <div className="level-cell level-entry"><span>ENTRY ZONE</span><strong>{price(selected.entryLow)}–{price(selected.entryHigh)}</strong></div>
                <div className="level-cell"><span>BREAKOUT</span><strong>{price(selected.breakout)}</strong></div>
                <div className="level-cell level-stop"><span>STOP</span><strong>{price(selected.stopLoss)}</strong></div>
                <div className="level-cell"><span>TP1</span><strong>{price(selected.target1)}</strong></div>
                <div className="level-cell"><span>TP2</span><strong>{price(selected.target2)}</strong></div>
                <div className="level-cell"><span>TP3</span><strong>{price(selected.target3)}</strong></div>
              </div>
              <div className="risk-line">
                <span>R:R to TP2 <strong>{rr.toFixed(2)}R</strong></span>
                <span>Cancel below <strong>{price(selected.cancelBelow)}</strong></span>
                <span>Max risk <strong>{Number(selected.riskPercent).toFixed(2)}%</strong></span>
                {!["completed", "stopped", "cancelled"].includes(selected.status) && (
                  <button className="ml-auto text-xs text-red-300 underline decoration-red-400/30 underline-offset-4 hover:text-red-200" onClick={() => {
                    if (window.confirm("Cancel this paper setup? This records the cancellation.")) cancel.mutate({ id: selected.id });
                  }}>{cancel.isPending ? "Cancelling…" : "Cancel setup"}</button>
                )}
              </div>
            </>
          ) : (
            <div className="empty-setup">
              <Radar size={28} className="text-cyan-300" />
              <h2 className="mt-3 font-mono text-lg">No setup for {pair(symbol)}</h2>
              <p className="mt-2 max-w-md text-sm leading-6 text-slate-400">Create a conditional paper plan. The scanner will wait for a closed 4H breakout before allowing the retest entry.</p>
              <button className="button-primary mt-5" onClick={() => setNewOpen(true)}><Plus size={16} /> Create {pair(symbol)} setup</button>
            </div>
          )}

          <div className="ledger-section">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <p className="section-label">OPPORTUNITY RADAR</p>
                <p className="section-subtitle">120 markets • 20 baseline + 8 Elite slots • forward paper evidence</p>
              </div>
              <div className="filter-tabs" role="group" aria-label="Filter setups">
                {["all", "radar", "elite", "open", "active", "closed"].map((item) => (
                  <button key={item} className={filter === item ? "filter-active" : ""} onClick={() => setFilter(item)}>{item.toUpperCase()}</button>
                ))}
              </div>
            </div>
            <div className="ledger-list">
              {filtered.map((setup) => (
                <button key={setup.id} className={`ledger-row ${selected?.id === setup.id ? "ledger-selected" : ""}`} onClick={() => { setWorkspace("radar"); setSelectedId(setup.id); setSelectedSymbol(setup.symbol); }}>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="truncate font-mono text-xs font-medium">{pair(setup.symbol)}</p>
                      {setup.source === "radar" && <span className={setup.strategy === "breakout_daily_elite" ? "elite-badge" : "radar-score"}>{setup.strategy === "breakout_daily_elite" ? "ELITE " : ""}{setup.score}/99</span>}
                    </div>
                    <p className="mt-1 text-[11px] text-slate-500">Entry {price(setup.entryLow)}–{price(setup.entryHigh)}</p>
                    {setup.source === "radar" && setup.reason && <p className="ledger-reason">{setup.reason}</p>}
                  </div>
                  <span className={`setup-status ${statusMeta[setup.status]?.className}`}>{statusMeta[setup.status]?.label}</span>
                  <ChevronRight size={14} className="text-slate-600" />
                </button>
              ))}
              {!filtered.length && <p className="px-3 py-8 text-center text-sm text-slate-500">No setups in this view.</p>}
            </div>
          </div>
            </>
          )}
        </section>

        <aside className="alerts-panel" aria-label="Alert stream">
          <div className="panel-heading">
            <div>
              <p className="section-label">ALERT STREAM</p>
              <p className="section-subtitle">Persistent paper journal</p>
            </div>
            <Bell size={15} className="text-cyan-300" />
          </div>
          {scanNote && <p role="status" className="border-b border-[#1a2540] px-4 py-2 font-mono text-[10px] text-cyan-200">{scanNote}</p>}
          <div className="alert-timeline">
            {(alertsQuery.data ?? []).slice(0, 16).map(({ alert, symbol: alertSymbol, strategy }) => (
              <div key={alert.id} className={`alert-event alert-${alert.kind}`}>
                <div className="alert-node"><AlertIcon kind={alert.kind} /></div>
                <div className="min-w-0 pb-5">
                  <div className="flex items-center justify-between gap-2">
                    <span className={`font-mono text-[10px] ${strategy === "breakout_daily_elite" ? "elite-text" : "text-slate-500"}`}>{pair(alertSymbol)}{strategy === "breakout_daily_elite" ? " • ELITE" : ""}</span>
                    <time className="text-[10px] text-slate-600">{time(alert.createdAt)}</time>
                  </div>
                  <p className="mt-1 text-sm font-medium leading-5 text-slate-200">{alert.title}</p>
                  <p className="mt-1 text-xs leading-5 text-slate-400">{alert.message}</p>
                </div>
              </div>
            ))}
            {alertsQuery.isLoading && <p className="py-8 text-center font-mono text-xs text-slate-500">LOADING JOURNAL…</p>}
            {!alertsQuery.isLoading && !alertsQuery.data?.length && (
              <div className="px-4 py-10 text-center"><Bell size={22} className="mx-auto text-slate-600" /><p className="mt-3 text-sm text-slate-500">Alerts will appear after the first scan.</p></div>
            )}
          </div>
          <button className="telegram-strip" onClick={() => setTelegramOpen(true)}>
            <Send size={16} />
            <div className="min-w-0 flex-1 text-left">
              <p className="text-sm font-medium">Telegram alerts</p>
              <p className="truncate text-xs text-slate-500">{telegramQuery.data?.configured ? "Connected • send a test" : "Optional • configure delivery"}</p>
            </div>
            <ChevronRight size={15} />
          </button>
        </aside>
      </main>

      <footer className="app-footer">
        <span>Public Binance spot data • 120-market dual radar • Elite forward paper track</span>
        <span>{tickersQuery.data?.asOf ? `Updated ${time(new Date(tickersQuery.data.asOf))}` : "Connecting…"}</span>
        <span className="text-amber-200/80">Education & paper tracking only — not financial advice.</span>
      </footer>

      <NewSetupDialog key={`${newOpen}-${selectedSymbol}`} open={newOpen} onOpenChange={setNewOpen} defaultSymbol={selectedSymbol} onCreated={(id) => { setWorkspace("radar"); setSelectedId(id); refreshQueries(); }} />
      <TelegramDialog open={telegramOpen} onOpenChange={setTelegramOpen} />
    </div>
  );
}
