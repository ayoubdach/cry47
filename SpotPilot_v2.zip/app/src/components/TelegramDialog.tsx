import { useState } from "react";
import { Send, X } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import { trpc } from "@/providers/trpc";

export function TelegramDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (open: boolean) => void }) {
  const status = trpc.telegram.status.useQuery();
  const [result, setResult] = useState("");
  const test = trpc.telegram.test.useMutation({
    onSuccess: (data) => setResult(data.delivered ? "Test alert delivered." : "Telegram is not configured yet."),
    onError: (error) => setResult(error.message),
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg border-[#1a2540] bg-[#0c1220] p-0 text-slate-100 sm:rounded-xl" showCloseButton={false}>
        <div className="flex items-start justify-between border-b border-[#1a2540] px-5 py-4">
          <div>
            <DialogTitle className="font-mono text-lg">Telegram delivery</DialogTitle>
            <DialogDescription className="mt-1 text-sm text-slate-400">Server-side alerts. Your token never reaches the browser.</DialogDescription>
          </div>
          <button className="icon-button" onClick={() => onOpenChange(false)} aria-label="Close Telegram settings"><X size={18} /></button>
        </div>
        <div className="p-5">
          <div className="flex items-center gap-3 border-b border-[#1a2540] pb-4">
            <span className={`status-dot ${status.data?.configured ? "bg-emerald-400" : "bg-amber-400"}`} />
            <div>
              <p className="font-medium">{status.data?.configured ? "Connected" : "Not connected"}</p>
              <p className="text-sm text-slate-400">{status.data?.chatLabel ?? "Checking configuration…"}</p>
            </div>
          </div>
          <ol className="my-5 space-y-3 text-sm leading-6 text-slate-300">
            <li><span className="mr-2 font-mono text-cyan-300">01</span>Create a bot with @BotFather and copy its token.</li>
            <li><span className="mr-2 font-mono text-cyan-300">02</span>Message the bot once, then obtain your chat ID.</li>
            <li><span className="mr-2 font-mono text-cyan-300">03</span>Set TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID in the server environment and restart.</li>
          </ol>
          <p className="text-sm leading-6 text-slate-400">Until then, the dashboard and paper journal work normally. No Telegram messages are simulated.</p>
          {result && <p role="status" className="mt-4 text-sm text-cyan-200">{result}</p>}
          <button className="button-primary mt-6 w-full" disabled={!status.data?.configured || test.isPending} onClick={() => test.mutate()}>
            <Send size={16} /> {test.isPending ? "Sending…" : "Send test alert"}
          </button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
