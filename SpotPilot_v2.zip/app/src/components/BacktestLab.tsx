import { useMemo, useState } from "react";
import {
  AlertTriangle,
  BarChart3,
  CheckCircle2,
  Clock3,
  Database,
  FlaskConical,
  Play,
  ShieldCheck,
  TrendingUp,
} from "lucide-react";
import { trpc } from "@/providers/trpc";

type ReportKey = "breakout" | "breakout_daily" | "breakout_daily_elite" | "trend_pullback" | "pullback_small" | "legacy_confirmed";
type TradeFilter = "all" | ReportKey;

const META: Record<ReportKey, { label: string; short: string; tag: string; execution: string; color: string }> = {
  breakout: {
    label: "Breakout · zone touch",
    short: "Breakout",
    tag: "BASELINE",
    execution: "4H breakout → zone touch at midpoint",
    color: "#fbbf24",
  },
  breakout_daily: {
    label: "Breakout · Daily filter",
    short: "Daily breakout",
    tag: "TREND FILTER",
    execution: "Daily uptrend → 4H breakout → zone touch",
    color: "#22d3ee",
  },
  breakout_daily_elite: {
    label: "Daily breakout · 85+",
    short: "Elite breakout",
    tag: "SCORE 85+",
    execution: "Daily uptrend • 4H breakout • score ≥85",
    color: "#a3e635",
  },
  trend_pullback: {
    label: "Daily/4H trend pullback",
    short: "Pullback",
    tag: "NEW STRATEGY",
    execution: "Bullish 4H EMA rejection → next 4H open",
    color: "#34d399",
  },
  pullback_small: {
    label: "Pullback · small targets",
    short: "Small targets",
    tag: "4% / 7% / 8%",
    execution: "Same pullback entry • fixed targets • 5-day exit",
    color: "#f472b6",
  },
  legacy_confirmed: {
    label: "Breakout · 4H confirmed",
    short: "4H confirmed",
    tag: "PREVIOUS TEST",
    execution: "Bullish 4H retest close",
    color: "#a78bfa",
  },
};

const REPORT_ORDER: ReportKey[] = ["breakout", "breakout_daily", "breakout_daily_elite", "trend_pullback", "pullback_small", "legacy_confirmed"];

function keyFor(item: { strategy: string; entryMode: string }): ReportKey {
  return item.strategy === "breakout" && item.entryMode === "confirmed"
    ? "legacy_confirmed"
    : item.strategy as ReportKey;
}

function pair(symbol: string) {
  return symbol.replace("USDT", "/USDT");
}

function dateTime(value: Date | string) {
  return new Intl.DateTimeFormat("en", {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  }).format(new Date(value));
}

function signed(value: number, suffix = "") {
  return `${value > 0 ? "+" : ""}${value.toFixed(2)}${suffix}`;
}

export function BacktestLab() {
  const utils = trpc.useUtils();
  const latest = trpc.backtests.latest.useQuery(undefined, { retry: 1 });
  const [markets, setMarkets] = useState(24);
  const [candles, setCandles] = useState(600);
  const [tradeFilter, setTradeFilter] = useState<TradeFilter>("all");
  const [note, setNote] = useState("");
  const runBacktest = trpc.backtests.run.useMutation({
    onSuccess: (result) => {
      setTradeFilter("all");
      setNote(result.busy
        ? "Another validation run is already working. Showing the latest saved report."
        : `Saved ${result.runs.length} reports from identical real market candles.`);
      utils.backtests.latest.invalidate();
    },
    onError: (error) => setNote(error.message),
  });

  const report = runBacktest.data ?? latest.data;
  const runs = useMemo(() => report?.runs ?? [], [report]);
  const trades = useMemo(() => report?.trades ?? [], [report]);
  const orderedRuns = REPORT_ORDER
    .map((key) => runs.find((run) => keyFor(run) === key))
    .filter((run) => run !== undefined);
  const visibleTrades = trades
    .filter((trade) => tradeFilter === "all" || keyFor(trade) === tradeFilter)
    .slice(0, 30);

  const enoughToCompare = runs.length > 0 && runs.every((run) => run.tradesCount >= 10);
  const ranked = [...runs].sort((a, b) => b.expectancyR - a.expectancyR);
  const best = ranked[0];
  const leader = enoughToCompare && best
    ? ranked.every((run) => run.expectancyR < 0)
      ? `All negative; ${META[keyFor(best)].short} lost least`
      : `${META[keyFor(best)].short} leads this sample`
    : "Collect at least 10 closed trades per strategy before judging";

  const equity = useMemo(() => {
    const series = orderedRuns.map((run) => {
      const key = keyFor(run);
      let total = 0;
      const points = trades
        .filter((trade) => keyFor(trade) === key)
        .sort((a, b) => new Date(a.exitTime).getTime() - new Date(b.exitTime).getTime())
        .map((trade) => {
          total += trade.rMultiple;
          return { time: new Date(trade.exitTime).getTime(), value: total };
        });
      return { key, points };
    });
    const points = series.flatMap((item) => item.points);
    if (!points.length) return { series, paths: [] as string[], min: 0, max: 0 };
    const start = Math.min(...points.map((point) => point.time));
    const end = Math.max(...points.map((point) => point.time), start + 1);
    const min = Math.min(0, ...points.map((point) => point.value));
    const max = Math.max(0, ...points.map((point) => point.value));
    const range = Math.max(max - min, 1);
    const paths = series.map((item) => item.points.map((point, index) => {
      const x = 42 + ((point.time - start) / (end - start)) * 730;
      const y = 176 - ((point.value - min) / range) * 142;
      return `${index ? "L" : "M"}${x.toFixed(1)},${y.toFixed(1)}`;
    }).join(" "));
    return { series, paths, min, max };
  }, [orderedRuns, trades]);

  const scoreRows = [
    { label: "65–74", min: 65, max: 74 },
    { label: "75–84", min: 75, max: 84 },
    { label: "85–99", min: 85, max: 99 },
  ].map((bucket) => {
    const matches = trades.filter((trade) => trade.score >= bucket.min && trade.score <= bucket.max);
    const net = matches.reduce((sum, trade) => sum + trade.rMultiple, 0);
    return {
      ...bucket,
      count: matches.length,
      expectancy: matches.length ? net / matches.length : 0,
      wins: matches.filter((trade) => trade.rMultiple > 0).length,
    };
  });

  function startRun() {
    setNote("");
    runBacktest.mutate({ markets, candles });
  }

  return (
    <section className="strategy-lab" aria-label="Historical strategy validation">
      <div className="lab-heading">
        <div>
          <div className="flex items-center gap-2">
            <FlaskConical size={18} className="text-cyan-300" />
            <h1 className="font-mono text-lg font-semibold tracking-tight sm:text-xl">STRATEGY LAB</h1>
          </div>
          <p className="mt-1 max-w-2xl text-sm leading-6 text-slate-400">
            Same markets. Same candles. Five approaches. Measure before trusting.
          </p>
        </div>
        <button className="button-primary" onClick={startRun} disabled={runBacktest.isPending}>
          <Play size={15} /> {runBacktest.isPending ? "Validating…" : "Run comparison"}
        </button>
      </div>

      <div className="lab-controls">
        <label>
          <span className="field-label">Liquid markets</span>
          <select className="field-input" value={markets} onChange={(event) => setMarkets(Number(event.target.value))} disabled={runBacktest.isPending}>
            <option value={12}>12 markets</option>
            <option value={24}>24 markets</option>
            <option value={40}>40 markets</option>
          </select>
        </label>
        <label>
          <span className="field-label">4H candles per market</span>
          <select className="field-input" value={candles} onChange={(event) => setCandles(Number(event.target.value))} disabled={runBacktest.isPending}>
            <option value={300}>300 candles</option>
            <option value={600}>600 candles</option>
            <option value={1000}>1,000 candles</option>
            <option value={1500}>1,500 candles · ~250 days</option>
            <option value={3000}>3,000 candles · ~500 days</option>
          </select>
        </label>
        <div className="lab-assumption">
          <ShieldCheck size={16} />
          <span>10 bps fees + 5 bps slippage per side<br />Real Daily + 4H candles • stop-first ambiguity</span>
        </div>
      </div>

      {note && <p role="status" className="lab-note">{note}</p>}
      {runBacktest.isPending && (
        <div className="lab-progress" role="status">
          <span className="status-dot bg-cyan-300" />
          Downloading real Daily and 4H candles, then simulating all five approaches. Larger tests can take several minutes.
        </div>
      )}

      {!runs.length && !runBacktest.isPending ? (
        <div className="lab-empty">
          <BarChart3 size={30} className="text-cyan-300" />
          <h2 className="mt-4 font-mono text-lg">No saved validation report yet</h2>
          <p className="mt-2 max-w-xl text-sm leading-6 text-slate-400">
            Compare standard, Daily-filtered, and score-85+ breakouts with two pullback target models on real Binance spot candles. Reports persist for your next visit.
          </p>
        </div>
      ) : (
        <>
          <div className="lab-verdict">
            <TrendingUp size={18} />
            <div>
              <span>WHAT THIS SAMPLE SAYS</span>
              <strong>{leader}</strong>
              <p>Ranked by expectancy after costs. Historical leadership is not a future win guarantee.</p>
            </div>
          </div>

          <div className="mode-reports">
            {orderedRuns.map((run) => {
              const key = keyFor(run);
              const meta = META[key];
              return (
                <article className="mode-report" key={run.id}>
                  <div className="mode-title">
                    <div>
                      <span style={{ color: meta.color }}>{meta.tag}</span>
                      <h2>{meta.label}</h2>
                    </div>
                    <span className="mode-badge" style={{ color: meta.color, borderColor: `${meta.color}55` }}>{run.tradesCount} CLOSED</span>
                  </div>
                  <p className="mode-execution">{meta.execution}</p>
                  <div className="expectancy-row">
                    <div><span>EXPECTANCY / TRADE</span><strong className={run.expectancyR >= 0 ? "text-emerald-300" : "text-red-300"}>{signed(run.expectancyR, "R")}</strong></div>
                    <div><span>NET RESULT</span><strong className={run.netR >= 0 ? "text-emerald-300" : "text-red-300"}>{signed(run.netR, "R")}</strong></div>
                  </div>
                  {run.recentPeriodStart && (
                    <div className="recent-validation">
                      <div>
                        <span>RECENT 30% · ROBUSTNESS CHECK</span>
                        <span>{run.recentTradesCount} closed</span>
                      </div>
                      <p>
                        <strong className={run.recentExpectancyR >= 0 ? "text-emerald-300" : "text-red-300"}>{signed(run.recentExpectancyR, "R")} / trade</strong>
                        <span>{signed(run.recentNetR, "R")} net · PF {run.recentProfitFactor === null ? "—" : run.recentProfitFactor.toFixed(2)}</span>
                      </p>
                    </div>
                  )}
                  <div className="metric-grid">
                    <div><span>Win rate</span><strong>{run.winRate.toFixed(1)}%</strong></div>
                    <div><span>Profit factor</span><strong>{run.profitFactor === null ? "—" : run.profitFactor.toFixed(2)}</strong></div>
                    <div><span>Max drawdown</span><strong className="text-red-300">{run.maxDrawdownR.toFixed(2)}R</strong></div>
                    <div><span>Wins / losses</span><strong>{run.wins} / {run.losses}</strong></div>
                    <div><span>Setups detected</span><strong>{run.setups}</strong></div>
                    <div><span>Still open / pending</span><strong>{run.openCount} / {run.pendingCount}</strong></div>
                  </div>
                  {run.tradesCount < 30 && (
                    <p className="sample-warning"><AlertTriangle size={13} /> Small sample: {run.tradesCount} closed trades cannot prove an edge.</p>
                  )}
                </article>
              );
            })}
          </div>

          {runs[0] && (
            <div className="run-meta">
              <span><Database size={13} /> {runs[0].marketsScanned} markets • Daily + 4H feeds • {runs[0].feedErrors} errors</span>
              <span><Clock3 size={13} /> {dateTime(runs[0].periodStart)} → {dateTime(runs[0].periodEnd)}</span>
              <span><CheckCircle2 size={13} /> Saved {dateTime(runs[0].createdAt)}</span>
            </div>
          )}

          <div className="equity-panel">
            <div className="lab-section-heading">
              <div><p className="section-label">CUMULATIVE R</p><p className="section-subtitle">Closed-trade equity after estimated costs</p></div>
              <div className="equity-legend">
                {orderedRuns.map((run) => {
                  const key = keyFor(run);
                  return <span key={run.id} style={{ color: META[key].color }} className="equity-key">{META[key].short}</span>;
                })}
              </div>
            </div>
            {equity.paths.length ? (
              <svg className="equity-chart" viewBox="0 0 800 210" role="img" aria-label="Cumulative R strategy comparison chart">
                {[34, 82, 129, 176].map((y) => <line key={y} x1="42" x2="772" y1={y} y2={y} stroke="#1a2540" strokeWidth="1" />)}
                <line x1="42" x2="772" y1={176 - ((0 - equity.min) / Math.max(equity.max - equity.min, 1)) * 142} y2={176 - ((0 - equity.min) / Math.max(equity.max - equity.min, 1)) * 142} stroke="#52627a" strokeDasharray="4 4" />
                <text x="4" y="38" fill="#94a3b8" fontSize="11">{equity.max.toFixed(1)}R</text>
                <text x="4" y="180" fill="#94a3b8" fontSize="11">{equity.min.toFixed(1)}R</text>
                {equity.paths.map((path, index) => {
                  const key = equity.series[index].key;
                  return <path key={key} d={path} fill="none" stroke={META[key].color} strokeWidth="2.5" strokeLinejoin="round" strokeLinecap="round" />;
                })}
              </svg>
            ) : <p className="py-10 text-center text-sm text-slate-500">Closed trades will draw the equity curves.</p>}
          </div>

          <div className="score-audit">
            <div><p className="section-label">SCORE AUDIT</p><p className="section-subtitle">Combined strategies: does a higher score produce better historical outcomes?</p></div>
            <div className="score-table" role="table" aria-label="Strategy score performance">
              <div className="score-row score-header" role="row"><span>Score</span><span>Trades</span><span>Winners</span><span>Expectancy</span></div>
              {scoreRows.map((row) => (
                <div className="score-row" role="row" key={row.label}>
                  <strong>{row.label}</strong><span>{row.count}</span><span>{row.wins}</span>
                  <span className={row.count && row.expectancy >= 0 ? "text-emerald-300" : row.count ? "text-red-300" : ""}>{row.count ? signed(row.expectancy, "R") : "—"}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="trade-audit">
            <div className="lab-section-heading">
              <div><p className="section-label">TRADE AUDIT</p><p className="section-subtitle">Latest 30 closed simulated trades</p></div>
              <div className="filter-tabs" role="group" aria-label="Filter backtest trades">
                <button className={tradeFilter === "all" ? "filter-active" : ""} onClick={() => setTradeFilter("all")}>ALL</button>
                {orderedRuns.map((run) => {
                  const key = keyFor(run);
                  return <button key={run.id} className={tradeFilter === key ? "filter-active" : ""} onClick={() => setTradeFilter(key)}>{META[key].short.toUpperCase()}</button>;
                })}
              </div>
            </div>
            <div className="trade-table-wrap">
              <table className="trade-table">
                <thead><tr><th>Exit</th><th>Market</th><th>Strategy</th><th>Score</th><th>Outcome</th><th className="text-right">Net R</th><th className="text-right">Return</th></tr></thead>
                <tbody>
                  {visibleTrades.map((trade) => (
                    <tr key={trade.id}>
                      <td>{dateTime(trade.exitTime)}</td>
                      <td className="font-medium text-slate-200">{pair(trade.symbol)}</td>
                      <td>{META[keyFor(trade)].short}</td>
                      <td>{trade.score}</td>
                      <td>{trade.outcome === "completed"
                        ? "TP3 complete"
                        : trade.outcome === "timed_out"
                          ? `Time exit • ${trade.targetsHit} targets first`
                          : `Stop • ${trade.targetsHit} targets first`}</td>
                      <td className={`text-right ${trade.rMultiple >= 0 ? "text-emerald-300" : "text-red-300"}`}>{signed(trade.rMultiple, "R")}</td>
                      <td className={`text-right ${trade.returnPercent >= 0 ? "text-emerald-300" : "text-red-300"}`}>{signed(trade.returnPercent, "%")}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {!visibleTrades.length && <p className="py-8 text-center text-sm text-slate-500">No closed trades for this strategy.</p>}
            </div>
          </div>
        </>
      )}

      <div className="lab-method">
        <strong>Method, without hidden optimism:</strong> signals use only candles available at each step; today’s liquid market universe is used. Daily trend requires close above EMA50, EMA20 above EMA50, and rising EMA50. The elite variant applies an additional score-85 threshold to Daily breakouts. Pullback requires 4H EMA20 above EMA50, an EMA-zone touch, and a bullish close above the zone; entry is the next 4H open with targets recalculated from that fill. The small-target variant uses identical entries with fixed 4%, 7%, and 8% targets and exits any remainder at the close 30 candles (five days) after entry. Breakout touch fills at zone midpoint. Three equal target portions, gap-aware stops, and stop-first ambiguity apply. Unresolved trades are excluded from closed-trade metrics. Recent 30% cards are a regime-robustness check, not untouched out-of-sample proof. Historical results do not guarantee future performance.
      </div>
    </section>
  );
}
