import { useState, type FormEvent } from "react";
import { Plus, X } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import { SUPPORTED_SYMBOLS } from "@contracts/constants";
import { trpc } from "@/providers/trpc";

const fields = [
  ["breakout", "4H breakout", "7.12"],
  ["entryLow", "Entry low", "6.98"],
  ["entryHigh", "Entry high", "7.06"],
  ["stopLoss", "Stop-loss", "6.76"],
  ["cancelBelow", "Cancel below", "6.78"],
  ["target1", "Target 1", "7.30"],
  ["target2", "Target 2", "7.58"],
  ["target3", "Target 3", "7.78"],
  ["riskPercent", "Max account risk %", "0.50"],
] as const;

export function NewSetupDialog({ open, onOpenChange, defaultSymbol, onCreated }: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  defaultSymbol: string;
  onCreated: (id: number) => void;
}) {
  const utils = trpc.useUtils();
  const [error, setError] = useState("");
  const create = trpc.setups.create.useMutation({
    onSuccess: (setup) => {
      if (!setup) return;
      setError("");
      onOpenChange(false);
      onCreated(setup.id);
      utils.setups.list.invalidate();
      utils.alerts.list.invalidate();
    },
    onError: (err) => setError(err.message),
  });

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    setError("");
    create.mutate({
      symbol: String(form.get("symbol")),
      breakout: Number(form.get("breakout")),
      entryLow: Number(form.get("entryLow")),
      entryHigh: Number(form.get("entryHigh")),
      stopLoss: Number(form.get("stopLoss")),
      cancelBelow: Number(form.get("cancelBelow")),
      target1: Number(form.get("target1")),
      target2: Number(form.get("target2")),
      target3: Number(form.get("target3")),
      riskPercent: Number(form.get("riskPercent")),
      entryMode: form.get("entryMode") === "confirmed" ? "confirmed" : "touch",
    });
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[92dvh] max-w-2xl overflow-y-auto border-[#1a2540] bg-[#0c1220] p-0 text-slate-100 sm:rounded-xl" showCloseButton={false}>
        <div className="flex items-start justify-between border-b border-[#1a2540] px-5 py-4 sm:px-6">
          <div>
            <DialogTitle className="font-mono text-lg font-semibold tracking-wide">New paper setup</DialogTitle>
            <DialogDescription className="mt-1 text-sm text-slate-400">Breakout first. Retest second. Entry last.</DialogDescription>
          </div>
          <button className="icon-button" onClick={() => onOpenChange(false)} aria-label="Close new setup"><X size={18} /></button>
        </div>
        <form onSubmit={submit} className="p-5 sm:p-6">
          <label className="field-label" htmlFor="symbol">Spot pair</label>
          <select id="symbol" name="symbol" defaultValue={defaultSymbol} className="field-input mb-5" required>
            {Array.from(new Set([...SUPPORTED_SYMBOLS, defaultSymbol])).map((symbol) => <option key={symbol} value={symbol}>{symbol.replace("USDT", "/USDT")}</option>)}
          </select>
          <label className="field-label" htmlFor="entryMode">Entry confirmation</label>
          <select id="entryMode" name="entryMode" defaultValue="touch" className="field-input mb-5" required>
            <option value="touch">Zone touch — faster, more entries</option>
            <option value="confirmed">Bullish 4H close — slower, more selective</option>
          </select>
          <div className="grid grid-cols-2 gap-x-4 gap-y-4 sm:grid-cols-3">
            {fields.map(([name, label, initial]) => (
              <div key={name} className={name === "riskPercent" ? "col-span-2 sm:col-span-1" : ""}>
                <label className="field-label" htmlFor={name}>{label}</label>
                <input id={name} name={name} defaultValue={initial} type="number" min="0" step="any" inputMode="decimal" className="field-input" required />
              </div>
            ))}
          </div>
          <p className="mt-5 border-l border-cyan-400/40 pl-3 text-sm leading-6 text-slate-400">
            Required structure: stop &lt; entry &lt; breakout &lt; targets. Choose a faster zone-touch entry or a slower bullish 4H confirmation. Paper alerts only; never an exchange order.
          </p>
          {error && <p role="alert" className="mt-4 text-sm text-red-300">{error}</p>}
          <div className="mt-6 flex flex-col-reverse gap-3 sm:flex-row sm:justify-end">
            <button type="button" className="button-secondary" onClick={() => onOpenChange(false)}>Cancel</button>
            <button type="submit" className="button-primary" disabled={create.isPending}>
              <Plus size={16} /> {create.isPending ? "Creating…" : "Start watching"}
            </button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
