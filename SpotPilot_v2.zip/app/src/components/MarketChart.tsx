type Candle = {
  closeTime: number;
  close: number;
};

type Levels = {
  breakout: string;
  entryLow: string;
  entryHigh: string;
  stopLoss: string;
};

export function MarketChart({ candles, levels, symbol }: {
  candles: Candle[];
  levels?: Levels;
  symbol: string;
}) {
  const width = 760;
  const height = 250;
  const pad = { left: 18, right: 70, top: 20, bottom: 28 };
  const closes = candles.map((c) => c.close);
  const rawMin = Math.min(...closes);
  const rawMax = Math.max(...closes);
  const spread = Math.max(rawMax - rawMin, rawMax * 0.005);
  const min = rawMin - spread * 0.15;
  const max = rawMax + spread * 0.15;
  const x = (i: number) => pad.left + (i / Math.max(closes.length - 1, 1)) * (width - pad.left - pad.right);
  const y = (v: number) => pad.top + ((max - v) / (max - min)) * (height - pad.top - pad.bottom);
  const points = closes.map((v, i) => `${x(i)},${y(v)}`).join(" ");
  const area = closes.length
    ? `M ${x(0)} ${height - pad.bottom} L ${points.replaceAll(" ", " L ")} L ${x(closes.length - 1)} ${height - pad.bottom} Z`
    : "";
  const fmt = (v: number) => v >= 1000 ? v.toFixed(0) : v >= 100 ? v.toFixed(1) : v >= 1 ? v.toFixed(3) : v.toFixed(5);
  const levelList = levels ? [
    { label: "BREAKOUT", value: Number(levels.breakout), color: "#22d3ee" },
    { label: "ENTRY", value: (Number(levels.entryLow) + Number(levels.entryHigh)) / 2, color: "#34d399" },
    { label: "STOP", value: Number(levels.stopLoss), color: "#f87171" },
  ].filter((l) => l.value >= min && l.value <= max) : [];

  if (!candles.length) {
    return <div className="flex h-[250px] items-center justify-center text-sm text-slate-500">Waiting for market candles…</div>;
  }

  return (
    <svg viewBox={`0 0 ${width} ${height}`} className="h-auto w-full" role="img" aria-label={`${symbol} recent 4-hour closing prices`}>
      <defs>
        <linearGradient id="chartArea" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#22d3ee" stopOpacity="0.22" />
          <stop offset="100%" stopColor="#22d3ee" stopOpacity="0" />
        </linearGradient>
      </defs>
      {[0, 1, 2, 3].map((i) => {
        const yy = pad.top + (i / 3) * (height - pad.top - pad.bottom);
        return <line key={i} x1={pad.left} x2={width - pad.right} y1={yy} y2={yy} stroke="#1a2540" strokeWidth="1" />;
      })}
      <path d={area} fill="url(#chartArea)" />
      <polyline points={points} fill="none" stroke="#22d3ee" strokeWidth="2.2" strokeLinejoin="round" strokeLinecap="round" />
      {levelList.map((level) => (
        <g key={level.label}>
          <line x1={pad.left} x2={width - pad.right} y1={y(level.value)} y2={y(level.value)} stroke={level.color} strokeOpacity="0.65" strokeDasharray="5 6" />
          <text x={width - pad.right + 8} y={y(level.value) + 4} fill={level.color} fontSize="10" fontFamily="IBM Plex Mono, monospace">{level.label}</text>
        </g>
      ))}
      <circle cx={x(closes.length - 1)} cy={y(closes.at(-1)!)} r="4" fill="#22d3ee" className="chart-pulse" />
      <text x={pad.left} y={height - 7} fill="#9a9aab" fontSize="10" fontFamily="IBM Plex Mono, monospace">{fmt(min)}</text>
      <text x={width - pad.right} y={height - 7} textAnchor="end" fill="#9a9aab" fontSize="10" fontFamily="IBM Plex Mono, monospace">{fmt(max)}</text>
    </svg>
  );
}
