import {
  bigint,
  decimal,
  double,
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/mysql-core";

export const setups = mysqlTable("setups", {
  id: bigint("id", { mode: "number", unsigned: true }).primaryKey().autoincrement(),
  symbol: varchar("symbol", { length: 16 }).notNull(),
  breakout: decimal("breakout", { precision: 30, scale: 10 }).notNull(),
  entryLow: decimal("entry_low", { precision: 30, scale: 10 }).notNull(),
  entryHigh: decimal("entry_high", { precision: 30, scale: 10 }).notNull(),
  stopLoss: decimal("stop_loss", { precision: 30, scale: 10 }).notNull(),
  target1: decimal("target_1", { precision: 30, scale: 10 }).notNull(),
  target2: decimal("target_2", { precision: 30, scale: 10 }).notNull(),
  target3: decimal("target_3", { precision: 30, scale: 10 }).notNull(),
  cancelBelow: decimal("cancel_below", { precision: 30, scale: 10 }).notNull(),
  riskPercent: decimal("risk_percent", { precision: 5, scale: 2 }).notNull().default("0.50"),
  source: varchar("source", { length: 16 }).notNull().default("manual"),
  strategy: varchar("strategy", { length: 32 }).notNull().default("breakout"),
  entryMode: varchar("entry_mode", { length: 16 }).notNull().default("touch"),
  score: int("score").notNull().default(0),
  reason: text("reason"),
  status: mysqlEnum("status", [
    "waiting",
    "armed",
    "active",
    "tp1",
    "tp2",
    "completed",
    "stopped",
    "cancelled",
  ]).notNull().default("waiting"),
  lastPrice: decimal("last_price", { precision: 30, scale: 10 }),
  armedAt: timestamp("armed_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const alerts = mysqlTable("alerts", {
  id: bigint("id", { mode: "number", unsigned: true }).primaryKey().autoincrement(),
  setupId: bigint("setup_id", { mode: "number", unsigned: true })
    .notNull()
    .references(() => setups.id, { onDelete: "cascade" }),
  kind: varchar("kind", { length: 32 }).notNull(),
  title: varchar("title", { length: 180 }).notNull(),
  message: text("message").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const backtestRuns = mysqlTable("backtest_runs", {
  id: bigint("id", { mode: "number", unsigned: true }).primaryKey().autoincrement(),
  groupId: varchar("group_id", { length: 36 }).notNull(),
  strategy: varchar("strategy", { length: 32 }).notNull().default("breakout"),
  entryMode: varchar("entry_mode", { length: 16 }).notNull(),
  marketsRequested: int("markets_requested").notNull(),
  candleLimit: int("candle_limit").notNull(),
  marketsScanned: int("markets_scanned").notNull(),
  feedErrors: int("feed_errors").notNull().default(0),
  feeBps: int("fee_bps").notNull(),
  slippageBps: int("slippage_bps").notNull(),
  periodStart: timestamp("period_start").notNull(),
  periodEnd: timestamp("period_end").notNull(),
  setups: int("setups").notNull().default(0),
  cancelled: int("cancelled").notNull().default(0),
  openCount: int("open_count").notNull().default(0),
  pendingCount: int("pending_count").notNull().default(0),
  tradesCount: int("trades_count").notNull().default(0),
  wins: int("wins").notNull().default(0),
  losses: int("losses").notNull().default(0),
  winRate: double("win_rate").notNull().default(0),
  profitFactor: double("profit_factor"),
  expectancyR: double("expectancy_r").notNull().default(0),
  netR: double("net_r").notNull().default(0),
  maxDrawdownR: double("max_drawdown_r").notNull().default(0),
  recentPeriodStart: timestamp("recent_period_start"),
  recentTradesCount: int("recent_trades_count").notNull().default(0),
  recentWinRate: double("recent_win_rate").notNull().default(0),
  recentProfitFactor: double("recent_profit_factor"),
  recentExpectancyR: double("recent_expectancy_r").notNull().default(0),
  recentNetR: double("recent_net_r").notNull().default(0),
  recentMaxDrawdownR: double("recent_max_drawdown_r").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const backtestTrades = mysqlTable("backtest_trades", {
  id: bigint("id", { mode: "number", unsigned: true }).primaryKey().autoincrement(),
  runId: bigint("run_id", { mode: "number", unsigned: true })
    .notNull()
    .references(() => backtestRuns.id, { onDelete: "cascade" }),
  symbol: varchar("symbol", { length: 16 }).notNull(),
  strategy: varchar("strategy", { length: 32 }).notNull().default("breakout"),
  entryMode: varchar("entry_mode", { length: 16 }).notNull(),
  score: int("score").notNull(),
  detectedAt: timestamp("detected_at").notNull(),
  entryTime: timestamp("entry_time").notNull(),
  exitTime: timestamp("exit_time").notNull(),
  entryPrice: decimal("entry_price", { precision: 30, scale: 10 }).notNull(),
  exitPrice: decimal("exit_price", { precision: 30, scale: 10 }).notNull(),
  stopLoss: decimal("stop_loss", { precision: 30, scale: 10 }).notNull(),
  target1: decimal("target_1", { precision: 30, scale: 10 }).notNull(),
  target2: decimal("target_2", { precision: 30, scale: 10 }).notNull(),
  target3: decimal("target_3", { precision: 30, scale: 10 }).notNull(),
  outcome: varchar("outcome", { length: 24 }).notNull(),
  targetsHit: int("targets_hit").notNull().default(0),
  rMultiple: double("r_multiple").notNull(),
  returnPercent: double("return_percent").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type Setup = typeof setups.$inferSelect;
export type InsertSetup = typeof setups.$inferInsert;
export type Alert = typeof alerts.$inferSelect;
export type BacktestRun = typeof backtestRuns.$inferSelect;
export type BacktestTradeRow = typeof backtestTrades.$inferSelect;
