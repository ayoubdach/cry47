import { relations } from "drizzle-orm";
import { alerts, backtestRuns, backtestTrades, setups } from "./schema";

export const setupsRelations = relations(setups, ({ many }) => ({
  alerts: many(alerts),
}));

export const alertsRelations = relations(alerts, ({ one }) => ({
  setup: one(setups, { fields: [alerts.setupId], references: [setups.id] }),
}));

export const backtestRunsRelations = relations(backtestRuns, ({ many }) => ({
  trades: many(backtestTrades),
}));

export const backtestTradesRelations = relations(backtestTrades, ({ one }) => ({
  run: one(backtestRuns, { fields: [backtestTrades.runId], references: [backtestRuns.id] }),
}));
