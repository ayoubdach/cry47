# SpotPilot

SpotPilot is a paper-trading research terminal for Binance spot breakout–retest setups. It scans public market data, tracks setup states, records simulated outcomes, and can send optional Telegram alerts. It does not connect to an exchange account or place real orders.

## What it does

- Scans up to 120 liquid USDT spot markets with two independent forward paper tracks: up to 20 baseline breakout setups and up to 8 Elite Breakout setups.
- Elite Breakout requires score ≥85 and a Daily uptrend at discovery. Before an Elite retest can activate, the scanner fetches fresh Daily candles and rechecks that trend; failure cancels the setup before entry.
- Elite and baseline setups retain separate strategy identities, capacity limits, cooldowns, labels, and Telegram messages, including when both tracks watch the same symbol.
- Requires at least $5M rolling 24H quote volume. Markets below $10M need a higher quality score.
- Follows the sequence **4H breakout → retest → paper entry**. An entry-zone touch before a breakout is not an entry.
- Supports two entry modes:
  - **Zone touch:** enter at the valid zone after a confirmed breakout.
  - **4H confirmed:** wait for a later bullish 4H candle that touches the zone and closes above its upper boundary.
- Tracks waiting, armed, active, target, stopped, completed, and cancelled states.
- Records paper entries, three equal target portions, gap-aware stops, alerts, and outcomes in MySQL.
- Runs setup checks every 90 seconds and refreshes radar discovery every 15 minutes.

## Strategy Lab

The Strategy Lab compares five approaches on identical real historical candles and saves the resulting reports and trade ledger:

1. Current 4H breakout–retest with zone-touch entries.
2. Breakout–retest filtered by a Daily uptrend (close above EMA50, EMA20 above EMA50, and rising EMA50).
3. The same Daily-filtered breakout with an additional score-85 threshold, isolated to measure quality filtering and market concentration.
4. Daily-trend pullback with 4H EMA20 above EMA50, an EMA-zone touch, bullish confirmation, and entry at the next 4H open.
5. The same pullback entries with fixed 4%, 7%, and 8% targets and a five-day time exit for any remaining portion.

Tests can use 12, 24, or 40 markets and 300, 600, 1,000, 1,500, or 3,000 4H candles per market (up to roughly 500 days). Candle history is paginated through Binance's 1,000-row limit, and the Daily lookback expands with the requested 4H range. Pullback targets are recalculated from the actual next-open entry rather than assumed from the confirmation close. The small-target time exit occurs at the close 30 4H candles after entry; stops and targets are evaluated first on that candle.

Each saved report includes full-period metrics and a separate recent-30% robustness segment based on signal detection time. The recent segment helps reveal regime dependence; it is not represented as untouched out-of-sample validation.

The simulator includes:

- 10 bps fees and 5 bps slippage per side by default.
- No entry on the breakout candle itself.
- No target credit on the touch-entry candle because 4H OHLC cannot establish intracandle order.
- Stop-first handling when stop and targets occur in the same candle.
- Closed-trade R multiples, expectancy, net R, profit factor, drawdown, score buckets, and cumulative-R curves.

Historical results are evidence about one sample, not a promise of future returns. The market universe is selected from currently liquid markets, so the test has survivorship bias. Open and unresolved trades are excluded from closed-trade performance metrics.

## Development

```bash
npm install
npm run dev
npm run check
npm run test
npm run build
npm start
```

The application runs on port 3000. Production builds write the frontend to `dist/public` and the bundled server to `dist/boot.js`.

## Database

Schema changes are additive and managed through Drizzle migrations:

```bash
npm run db:generate
npm run db:migrate
```

Do not use destructive migration recovery or `db:push --force` on a database containing setup history.

## Telegram alerts

Set `TELEGRAM_BOT_TOKEN` and `TELEGRAM_CHAT_ID` in the server environment. These values remain server-side. If they are absent, alerts remain available in the dashboard and Telegram is reported as unconfigured rather than delivered.

Every opportunity receives its own complete Telegram ticket with strategy, score, status, breakout, exact entry zone, stop-loss, TP1, TP2, TP3, cancellation level, and planned risk. Breakout, entry, TP1, TP2, final target, stop, cancellation, manual setup, and expiry events also trigger alerts; target and entry messages retain the complete level ladder.

## Safety and scope

SpotPilot uses public Binance market data and needs no exchange login or exchange API key. It is for research and paper trading only. Never provide a seed phrase, private key, or withdrawal-enabled exchange credential to a signal service or trading tool.
